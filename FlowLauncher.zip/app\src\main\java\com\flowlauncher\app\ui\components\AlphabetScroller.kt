package com.flowlauncher.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val ALPHABET = ('A'..'Z').toList()
private const val SCROLLER_WIDTH_DP = 32
private const val POPUP_SIZE_DP = 56

@Composable
fun AlphabetScroller(
    modifier: Modifier = Modifier,
    availableLetters: Set<Char> = emptySet(),
    currentLetter: Char = 'A',
    onLetterSelected: (Char) -> Unit = {}
) {
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    var isTouching by remember { mutableStateOf(false) }
    var touchY by remember { mutableFloatStateOf(0f) }
    var hoveredLetter by remember { mutableStateOf<Char?>(null) }
    var previousHoveredLetter by remember { mutableStateOf<Char?>(null) }
    var scrollerHeight by remember { mutableFloatStateOf(0f) }
    var scrollerTopY by remember { mutableFloatStateOf(0f) }

    // Animate scroller opacity
    val scrollerAlpha by animateFloatAsState(
        targetValue = if (isTouching) 1f else 0.6f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "scroller_alpha"
    )

    // Popup scale animation
    val popupScale by animateFloatAsState(
        targetValue = if (isTouching && hoveredLetter != null) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "popup_scale"
    )

    val popupAlpha by animateFloatAsState(
        targetValue = if (isTouching && hoveredLetter != null) 1f else 0f,
        animationSpec = tween(150, easing = EaseOutCubic),
        label = "popup_alpha"
    )

    // Background pill alpha
    val pillAlpha by animateFloatAsState(
        targetValue = if (isTouching) 0.12f else 0.06f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "pill_alpha"
    )

    // Calculate letter from touch position
    fun letterFromY(y: Float): Char? {
        if (scrollerHeight <= 0f) return null
        val relativeY = (y / scrollerHeight).coerceIn(0f, 1f)
        val index = (relativeY * (ALPHABET.size - 1)).roundToInt()
        return ALPHABET.getOrNull(index)
    }

    // Handle letter changes with haptic
    fun onLetterHovered(letter: Char?) {
        if (letter != null && letter != previousHoveredLetter) {
            previousHoveredLetter = letter
            hoveredLetter = letter
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            if (availableLetters.contains(letter)) {
                onLetterSelected(letter)
            }
        }
    }

    Box(modifier = modifier) {
        // Letter popup indicator (appears to the left)
        if (hoveredLetter != null) {
            val letterIndex = ALPHABET.indexOf(hoveredLetter!!)
            val letterFraction = if (ALPHABET.isNotEmpty()) {
                letterIndex.toFloat() / (ALPHABET.size - 1).coerceAtLeast(1)
            } else 0f

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(
                        x = (-SCROLLER_WIDTH_DP - POPUP_SIZE_DP - 8).dp,
                        y = with(density) {
                            val yPos = scrollerHeight * letterFraction
                            val popupHalf = POPUP_SIZE_DP.dp.toPx() / 2
                            (yPos - popupHalf).toDp()
                        }
                    )
                    .graphicsLayer {
                        this.scaleX = popupScale
                        this.scaleY = popupScale
                        this.alpha = popupAlpha
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 0.5f)
                    }
                    .size(POPUP_SIZE_DP.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = (hoveredLetter ?: ' ').toString(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Scroller strip
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(SCROLLER_WIDTH_DP.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    MaterialTheme.colorScheme.onBackground.copy(alpha = pillAlpha)
                )
                .onGloballyPositioned { coordinates ->
                    scrollerHeight = coordinates.size.height.toFloat()
                    scrollerTopY = coordinates.positionInParent().y
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = { offset ->
                            isTouching = true
                            val letter = letterFromY(offset.y)
                            onLetterHovered(letter)
                            val released = tryAwaitRelease()
                            isTouching = false
                            hoveredLetter = null
                            previousHoveredLetter = null
                        }
                    )
                }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            isTouching = true
                            val letter = letterFromY(offset.y)
                            onLetterHovered(letter)
                        },
                        onDragEnd = {
                            isTouching = false
                            hoveredLetter = null
                            previousHoveredLetter = null
                        },
                        onDragCancel = {
                            isTouching = false
                            hoveredLetter = null
                            previousHoveredLetter = null
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val letter = letterFromY(change.position.y)
                            onLetterHovered(letter)
                        }
                    )
                }
                .graphicsLayer { alpha = scrollerAlpha },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ALPHABET.forEach { letter ->
                    val isAvailable = availableLetters.contains(letter)
                    val isCurrent = letter == currentLetter
                    val isHovered = letter == hoveredLetter

                    val letterAlpha by animateFloatAsState(
                        targetValue = when {
                            isHovered -> 1f
                            isTouching && isAvailable -> 0.9f
                            isCurrent -> 0.95f
                            isAvailable -> if (isTouching) 0.7f else 0.5f
                            else -> if (isTouching) 0.25f else 0.2f
                        },
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "letter_alpha_$letter"
                    )

                    val letterScale by animateFloatAsState(
                        targetValue = when {
                            isHovered -> 1.3f
                            isCurrent -> 1.1f
                            else -> 1f
                        },
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "letter_scale_$letter"
                    )

                    val letterColor = when {
                        isHovered -> MaterialTheme.colorScheme.primary
                        isCurrent -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.onBackground
                    }

                    val letterWeight = when {
                        isHovered -> FontWeight.ExtraBold
                        isCurrent -> FontWeight.Bold
                        isAvailable -> FontWeight.Medium
                        else -> FontWeight.Light
                    }

                    Text(
                        text = letter.toString(),
                        fontSize = 11.sp,
                        fontWeight = letterWeight,
                        color = letterColor,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .graphicsLayer {
                                this.alpha = letterAlpha
                                this.scaleX = letterScale
                                this.scaleY = letterScale
                            }
                    )
                }
            }
        }
    }
}
