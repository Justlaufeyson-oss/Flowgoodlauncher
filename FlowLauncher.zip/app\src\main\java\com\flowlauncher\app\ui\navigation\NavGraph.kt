package com.flowlauncher.app.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.flowlauncher.app.ui.screens.HomeScreen
import com.flowlauncher.app.ui.screens.SettingsScreen
import com.flowlauncher.app.ui.theme.FlowLauncherTheme
import com.flowlauncher.app.viewmodel.LauncherViewModel

@Composable
fun FlowLauncherNavGraph(
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()
    val theme by viewModel.selectedTheme.collectAsState()
    val fontScale by viewModel.fontScale.collectAsState()

    FlowLauncherTheme(
        theme = theme,
        fontScale = fontScale
    ) {
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = modifier
        ) {
            composable(
                route = "home",
                enterTransition = { fadeIn(animationSpec = tween(250)) },
                exitTransition = { fadeOut(animationSpec = tween(250)) }
            ) {
                HomeScreen(
                    viewModel = viewModel,
                    navController = navController
                )
            }

            composable(
                route = "settings",
                enterTransition = {
                    slideIntoContainer(
                        towards = AnimatedContentTransitionScope.SlideDirection.Left,
                        animationSpec = tween(300)
                    ) + fadeIn(animationSpec = tween(300))
                },
                exitTransition = {
                    slideOutOfContainer(
                        towards = AnimatedContentTransitionScope.SlideDirection.Right,
                        animationSpec = tween(250)
                    ) + fadeOut(animationSpec = tween(250))
                }
            ) {
                SettingsScreen(
                    viewModel = viewModel,
                    navController = navController
                )
            }
        }
    }
}
