package com.flowlauncher.app.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.flowlauncher.app.model.LauncherTheme

// ──────────────────────────────────────────────
// DARK theme colors
// ──────────────────────────────────────────────
private val DarkPrimary = Color(0xFF6750A4)
private val DarkOnPrimary = Color(0xFFFFFFFF)
private val DarkPrimaryContainer = Color(0xFF4F378B)
private val DarkOnPrimaryContainer = Color(0xFFEADDFF)
private val DarkSecondary = Color(0xFFCCC2DC)
private val DarkOnSecondary = Color(0xFF332D41)
private val DarkSecondaryContainer = Color(0xFF4A4458)
private val DarkOnSecondaryContainer = Color(0xFFE8DEF8)
private val DarkTertiary = Color(0xFFEFB8C8)
private val DarkOnTertiary = Color(0xFF492532)
private val DarkBackground = Color(0xFF1C1B1F)
private val DarkOnBackground = Color(0xFFE6E1E5)
private val DarkSurface = Color(0xFF1C1B1F)
private val DarkOnSurface = Color(0xFFE6E1E5)
private val DarkSurfaceVariant = Color(0xFF49454F)
private val DarkOnSurfaceVariant = Color(0xFFCAC4D0)
private val DarkError = Color(0xFFF2B8B5)
private val DarkOnError = Color(0xFF601410)
private val DarkOutline = Color(0xFF938F99)

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary,
    onSecondary = DarkOnSecondary,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkOnSecondaryContainer,
    tertiary = DarkTertiary,
    onTertiary = DarkOnTertiary,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    error = DarkError,
    onError = DarkOnError,
    outline = DarkOutline
)

// ──────────────────────────────────────────────
// LIGHT theme colors
// ──────────────────────────────────────────────
private val LightPrimary = Color(0xFF1976D2)
private val LightOnPrimary = Color(0xFFFFFFFF)
private val LightPrimaryContainer = Color(0xFFBBDEFB)
private val LightOnPrimaryContainer = Color(0xFF0D47A1)
private val LightSecondary = Color(0xFF546E7A)
private val LightOnSecondary = Color(0xFFFFFFFF)
private val LightSecondaryContainer = Color(0xFFCFD8DC)
private val LightOnSecondaryContainer = Color(0xFF263238)
private val LightTertiary = Color(0xFF0097A7)
private val LightOnTertiary = Color(0xFFFFFFFF)
private val LightBackground = Color(0xFFFFFBFE)
private val LightOnBackground = Color(0xFF1C1B1F)
private val LightSurface = Color(0xFFFFFBFE)
private val LightOnSurface = Color(0xFF1C1B1F)
private val LightSurfaceVariant = Color(0xFFE7E0EC)
private val LightOnSurfaceVariant = Color(0xFF49454F)
private val LightError = Color(0xFFB3261E)
private val LightOnError = Color(0xFFFFFFFF)
private val LightOutline = Color(0xFF79747E)

private val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,
    tertiary = LightTertiary,
    onTertiary = LightOnTertiary,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    error = LightError,
    onError = LightOnError,
    outline = LightOutline
)

// ──────────────────────────────────────────────
// AMOLED theme colors
// ──────────────────────────────────────────────
private val AmoledPrimary = Color(0xFFBB86FC)
private val AmoledOnPrimary = Color(0xFF000000)
private val AmoledPrimaryContainer = Color(0xFF3700B3)
private val AmoledOnPrimaryContainer = Color(0xFFE8D5FF)
private val AmoledSecondary = Color(0xFF03DAC6)
private val AmoledOnSecondary = Color(0xFF000000)
private val AmoledSecondaryContainer = Color(0xFF005048)
private val AmoledOnSecondaryContainer = Color(0xFF70F7E9)
private val AmoledTertiary = Color(0xFFCF6679)
private val AmoledOnTertiary = Color(0xFF000000)
private val AmoledBackground = Color(0xFF000000)
private val AmoledOnBackground = Color(0xFFFFFFFF)
private val AmoledSurface = Color(0xFF000000)
private val AmoledOnSurface = Color(0xFFFFFFFF)
private val AmoledSurfaceVariant = Color(0xFF1A1A1A)
private val AmoledOnSurfaceVariant = Color(0xFFE0E0E0)
private val AmoledError = Color(0xFFCF6679)
private val AmoledOnError = Color(0xFF000000)
private val AmoledOutline = Color(0xFF444444)

private val AmoledColorScheme = darkColorScheme(
    primary = AmoledPrimary,
    onPrimary = AmoledOnPrimary,
    primaryContainer = AmoledPrimaryContainer,
    onPrimaryContainer = AmoledOnPrimaryContainer,
    secondary = AmoledSecondary,
    onSecondary = AmoledOnSecondary,
    secondaryContainer = AmoledSecondaryContainer,
    onSecondaryContainer = AmoledOnSecondaryContainer,
    tertiary = AmoledTertiary,
    onTertiary = AmoledOnTertiary,
    background = AmoledBackground,
    onBackground = AmoledOnBackground,
    surface = AmoledSurface,
    onSurface = AmoledOnSurface,
    surfaceVariant = AmoledSurfaceVariant,
    onSurfaceVariant = AmoledOnSurfaceVariant,
    error = AmoledError,
    onError = AmoledOnError,
    outline = AmoledOutline
)

// ──────────────────────────────────────────────
// OCEAN theme colors
// ──────────────────────────────────────────────
private val OceanPrimary = Color(0xFF006D77)
private val OceanOnPrimary = Color(0xFFFFFFFF)
private val OceanPrimaryContainer = Color(0xFF00838F)
private val OceanOnPrimaryContainer = Color(0xFFB2EBF2)
private val OceanSecondary = Color(0xFF83C5BE)
private val OceanOnSecondary = Color(0xFF0A2342)
private val OceanSecondaryContainer = Color(0xFF1B4965)
private val OceanOnSecondaryContainer = Color(0xFFB2DFDB)
private val OceanTertiary = Color(0xFF5AB1BB)
private val OceanOnTertiary = Color(0xFF0A2342)
private val OceanBackground = Color(0xFF0A2342)
private val OceanOnBackground = Color(0xFFE0F7FA)
private val OceanSurface = Color(0xFF0D2B4E)
private val OceanOnSurface = Color(0xFFE0F7FA)
private val OceanSurfaceVariant = Color(0xFF163A5F)
private val OceanOnSurfaceVariant = Color(0xFFB0BEC5)
private val OceanError = Color(0xFFFF8A80)
private val OceanOnError = Color(0xFF0A2342)
private val OceanOutline = Color(0xFF37687A)

private val OceanColorScheme = darkColorScheme(
    primary = OceanPrimary,
    onPrimary = OceanOnPrimary,
    primaryContainer = OceanPrimaryContainer,
    onPrimaryContainer = OceanOnPrimaryContainer,
    secondary = OceanSecondary,
    onSecondary = OceanOnSecondary,
    secondaryContainer = OceanSecondaryContainer,
    onSecondaryContainer = OceanOnSecondaryContainer,
    tertiary = OceanTertiary,
    onTertiary = OceanOnTertiary,
    background = OceanBackground,
    onBackground = OceanOnBackground,
    surface = OceanSurface,
    onSurface = OceanOnSurface,
    surfaceVariant = OceanSurfaceVariant,
    onSurfaceVariant = OceanOnSurfaceVariant,
    error = OceanError,
    onError = OceanOnError,
    outline = OceanOutline
)

// ──────────────────────────────────────────────
// SUNSET theme colors
// ──────────────────────────────────────────────
private val SunsetPrimary = Color(0xFFFF6B35)
private val SunsetOnPrimary = Color(0xFFFFFFFF)
private val SunsetPrimaryContainer = Color(0xFFBF360C)
private val SunsetOnPrimaryContainer = Color(0xFFFFCCBC)
private val SunsetSecondary = Color(0xFFFFAB91)
private val SunsetOnSecondary = Color(0xFF1A0A00)
private val SunsetSecondaryContainer = Color(0xFF4E342E)
private val SunsetOnSecondaryContainer = Color(0xFFFFCCBC)
private val SunsetTertiary = Color(0xFFFFD54F)
private val SunsetOnTertiary = Color(0xFF1A0A00)
private val SunsetBackground = Color(0xFF1A0A00)
private val SunsetOnBackground = Color(0xFFFFF3E0)
private val SunsetSurface = Color(0xFF211008)
private val SunsetOnSurface = Color(0xFFFFF3E0)
private val SunsetSurfaceVariant = Color(0xFF3E2723)
private val SunsetOnSurfaceVariant = Color(0xFFBCAAA4)
private val SunsetError = Color(0xFFFF8A80)
private val SunsetOnError = Color(0xFF1A0A00)
private val SunsetOutline = Color(0xFF6D4C41)

private val SunsetColorScheme = darkColorScheme(
    primary = SunsetPrimary,
    onPrimary = SunsetOnPrimary,
    primaryContainer = SunsetPrimaryContainer,
    onPrimaryContainer = SunsetOnPrimaryContainer,
    secondary = SunsetSecondary,
    onSecondary = SunsetOnSecondary,
    secondaryContainer = SunsetSecondaryContainer,
    onSecondaryContainer = SunsetOnSecondaryContainer,
    tertiary = SunsetTertiary,
    onTertiary = SunsetOnTertiary,
    background = SunsetBackground,
    onBackground = SunsetOnBackground,
    surface = SunsetSurface,
    onSurface = SunsetOnSurface,
    surfaceVariant = SunsetSurfaceVariant,
    onSurfaceVariant = SunsetOnSurfaceVariant,
    error = SunsetError,
    onError = SunsetOnError,
    outline = SunsetOutline
)

// ──────────────────────────────────────────────
// FOREST theme colors
// ──────────────────────────────────────────────
private val ForestPrimary = Color(0xFF2D6A4F)
private val ForestOnPrimary = Color(0xFFFFFFFF)
private val ForestPrimaryContainer = Color(0xFF1B5E20)
private val ForestOnPrimaryContainer = Color(0xFFC8E6C9)
private val ForestSecondary = Color(0xFF81C784)
private val ForestOnSecondary = Color(0xFF0B1A0F)
private val ForestSecondaryContainer = Color(0xFF2E7D32)
private val ForestOnSecondaryContainer = Color(0xFFA5D6A7)
private val ForestTertiary = Color(0xFF66BB6A)
private val ForestOnTertiary = Color(0xFF0B1A0F)
private val ForestBackground = Color(0xFF0B1A0F)
private val ForestOnBackground = Color(0xFFE8F5E9)
private val ForestSurface = Color(0xFF0F2214)
private val ForestOnSurface = Color(0xFFE8F5E9)
private val ForestSurfaceVariant = Color(0xFF1B3A22)
private val ForestOnSurfaceVariant = Color(0xFFA5D6A7)
private val ForestError = Color(0xFFEF9A9A)
private val ForestOnError = Color(0xFF0B1A0F)
private val ForestOutline = Color(0xFF4C8C5C)

private val ForestColorScheme = darkColorScheme(
    primary = ForestPrimary,
    onPrimary = ForestOnPrimary,
    primaryContainer = ForestPrimaryContainer,
    onPrimaryContainer = ForestOnPrimaryContainer,
    secondary = ForestSecondary,
    onSecondary = ForestOnSecondary,
    secondaryContainer = ForestSecondaryContainer,
    onSecondaryContainer = ForestOnSecondaryContainer,
    tertiary = ForestTertiary,
    onTertiary = ForestOnTertiary,
    background = ForestBackground,
    onBackground = ForestOnBackground,
    surface = ForestSurface,
    onSurface = ForestOnSurface,
    surfaceVariant = ForestSurfaceVariant,
    onSurfaceVariant = ForestOnSurfaceVariant,
    error = ForestError,
    onError = ForestOnError,
    outline = ForestOutline
)

// ──────────────────────────────────────────────
// ROSE theme colors
// ──────────────────────────────────────────────
private val RosePrimary = Color(0xFFE91E63)
private val RoseOnPrimary = Color(0xFFFFFFFF)
private val RosePrimaryContainer = Color(0xFFAD1457)
private val RoseOnPrimaryContainer = Color(0xFFF8BBD0)
private val RoseSecondary = Color(0xFFF48FB1)
private val RoseOnSecondary = Color(0xFF1A0A14)
private val RoseSecondaryContainer = Color(0xFF880E4F)
private val RoseOnSecondaryContainer = Color(0xFFF8BBD0)
private val RoseTertiary = Color(0xFFCE93D8)
private val RoseOnTertiary = Color(0xFF1A0A14)
private val RoseBackground = Color(0xFF1A0A14)
private val RoseOnBackground = Color(0xFFFCE4EC)
private val RoseSurface = Color(0xFF220E1A)
private val RoseOnSurface = Color(0xFFFCE4EC)
private val RoseSurfaceVariant = Color(0xFF3C1A2E)
private val RoseOnSurfaceVariant = Color(0xFFE1BEE7)
private val RoseError = Color(0xFFEF9A9A)
private val RoseOnError = Color(0xFF1A0A14)
private val RoseOutline = Color(0xFF8C5070)

private val RoseColorScheme = darkColorScheme(
    primary = RosePrimary,
    onPrimary = RoseOnPrimary,
    primaryContainer = RosePrimaryContainer,
    onPrimaryContainer = RoseOnPrimaryContainer,
    secondary = RoseSecondary,
    onSecondary = RoseOnSecondary,
    secondaryContainer = RoseSecondaryContainer,
    onSecondaryContainer = RoseOnSecondaryContainer,
    tertiary = RoseTertiary,
    onTertiary = RoseOnTertiary,
    background = RoseBackground,
    onBackground = RoseOnBackground,
    surface = RoseSurface,
    onSurface = RoseOnSurface,
    surfaceVariant = RoseSurfaceVariant,
    onSurfaceVariant = RoseOnSurfaceVariant,
    error = RoseError,
    onError = RoseOnError,
    outline = RoseOutline
)

// ──────────────────────────────────────────────
// Color scheme selector
// ──────────────────────────────────────────────

/**
 * Returns the Material3 [ColorScheme] for the given [LauncherTheme].
 *
 * @param theme the selected launcher theme
 * @param isDark ignored for themes that are inherently dark; used only for LIGHT/DARK toggle
 */
fun getColorScheme(theme: LauncherTheme, isDark: Boolean = true): ColorScheme {
    return when (theme) {
        LauncherTheme.DARK -> DarkColorScheme
        LauncherTheme.LIGHT -> if (isDark) DarkColorScheme else LightColorScheme
        LauncherTheme.AMOLED -> AmoledColorScheme
        LauncherTheme.OCEAN -> OceanColorScheme
        LauncherTheme.SUNSET -> SunsetColorScheme
        LauncherTheme.FOREST -> ForestColorScheme
        LauncherTheme.ROSE -> RoseColorScheme
    }
}

// ──────────────────────────────────────────────
// Gradient colors for home screen background overlay
// ──────────────────────────────────────────────

/**
 * Holds gradient colors for the home screen background overlay.
 * These are subtle gradients that complement each theme.
 */
data class ThemeGradientColors(
    val topColor: Color,
    val bottomColor: Color,
    val accentGlow: Color,
    val scrollerHighlight: Color,
    val clockColor: Color,
    val dividerColor: Color,
    val searchBarBackground: Color,
    val searchBarText: Color
)

/**
 * Returns the gradient and custom overlay colors for the given [LauncherTheme].
 */
fun getGradientColors(theme: LauncherTheme): ThemeGradientColors {
    return when (theme) {
        LauncherTheme.DARK -> ThemeGradientColors(
            topColor = Color(0x331C1B1F),
            bottomColor = Color(0x661C1B1F),
            accentGlow = Color(0x1A6750A4),
            scrollerHighlight = Color(0xFF6750A4),
            clockColor = Color(0xFFE6E1E5),
            dividerColor = Color(0x33938F99),
            searchBarBackground = Color(0xFF2B2930),
            searchBarText = Color(0xFFE6E1E5)
        )

        LauncherTheme.LIGHT -> ThemeGradientColors(
            topColor = Color(0x33FFFBFE),
            bottomColor = Color(0x66F5F5F5),
            accentGlow = Color(0x1A1976D2),
            scrollerHighlight = Color(0xFF1976D2),
            clockColor = Color(0xFF1C1B1F),
            dividerColor = Color(0x3379747E),
            searchBarBackground = Color(0xFFEEEEEE),
            searchBarText = Color(0xFF1C1B1F)
        )

        LauncherTheme.AMOLED -> ThemeGradientColors(
            topColor = Color(0x00000000),
            bottomColor = Color(0x33000000),
            accentGlow = Color(0x0DBB86FC),
            scrollerHighlight = Color(0xFFBB86FC),
            clockColor = Color(0xFFFFFFFF),
            dividerColor = Color(0x22FFFFFF),
            searchBarBackground = Color(0xFF0D0D0D),
            searchBarText = Color(0xFFFFFFFF)
        )

        LauncherTheme.OCEAN -> ThemeGradientColors(
            topColor = Color(0x330A2342),
            bottomColor = Color(0x66071A30),
            accentGlow = Color(0x1A006D77),
            scrollerHighlight = Color(0xFF006D77),
            clockColor = Color(0xFFE0F7FA),
            dividerColor = Color(0x3337687A),
            searchBarBackground = Color(0xFF163A5F),
            searchBarText = Color(0xFFE0F7FA)
        )

        LauncherTheme.SUNSET -> ThemeGradientColors(
            topColor = Color(0x331A0A00),
            bottomColor = Color(0x66140800),
            accentGlow = Color(0x1AFF6B35),
            scrollerHighlight = Color(0xFFFF6B35),
            clockColor = Color(0xFFFFF3E0),
            dividerColor = Color(0x336D4C41),
            searchBarBackground = Color(0xFF3E2723),
            searchBarText = Color(0xFFFFF3E0)
        )

        LauncherTheme.FOREST -> ThemeGradientColors(
            topColor = Color(0x330B1A0F),
            bottomColor = Color(0x66081208),
            accentGlow = Color(0x1A2D6A4F),
            scrollerHighlight = Color(0xFF2D6A4F),
            clockColor = Color(0xFFE8F5E9),
            dividerColor = Color(0x334C8C5C),
            searchBarBackground = Color(0xFF1B3A22),
            searchBarText = Color(0xFFE8F5E9)
        )

        LauncherTheme.ROSE -> ThemeGradientColors(
            topColor = Color(0x331A0A14),
            bottomColor = Color(0x66140810),
            accentGlow = Color(0x1AE91E63),
            scrollerHighlight = Color(0xFFE91E63),
            clockColor = Color(0xFFFCE4EC),
            dividerColor = Color(0x338C5070),
            searchBarBackground = Color(0xFF3C1A2E),
            searchBarText = Color(0xFFFCE4EC)
        )
    }
}
