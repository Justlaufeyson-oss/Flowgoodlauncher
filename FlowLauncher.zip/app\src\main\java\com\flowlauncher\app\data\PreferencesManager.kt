package com.flowlauncher.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.flowlauncher.app.model.ClockStyle
import com.flowlauncher.app.model.LauncherTheme
import com.flowlauncher.app.model.TextAlignment
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "flow_launcher_prefs")

class PreferencesManager(private val context: Context) {

    companion object Keys {
        val SELECTED_THEME = stringPreferencesKey("selected_theme")
        val CLOCK_STYLE = stringPreferencesKey("clock_style")
        val TEXT_ALIGNMENT = stringPreferencesKey("text_alignment")
        val FAVORITE_APPS = stringSetPreferencesKey("favorite_apps")
        val HIDDEN_APPS = stringSetPreferencesKey("hidden_apps")
        val CUSTOM_APP_LABELS = stringPreferencesKey("custom_app_labels")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val SHOW_CALENDAR = booleanPreferencesKey("show_calendar")
        val SHOW_WIDGET_STACK = booleanPreferencesKey("show_widget_stack")
        val HOME_SCREEN_APP_COUNT = intPreferencesKey("home_screen_app_count")
        val DOUBLE_TAP_TO_LOCK = booleanPreferencesKey("double_tap_to_lock")
        val SWIPE_DOWN_FOR_NOTIFICATIONS = booleanPreferencesKey("swipe_down_for_notifications")
    }

    // ── Theme ──────────────────────────────────────────────────────────
    val selectedTheme: Flow<LauncherTheme> = context.dataStore.data.map { prefs ->
        val name = prefs[SELECTED_THEME] ?: LauncherTheme.DARK.name
        try { LauncherTheme.valueOf(name) } catch (_: Exception) { LauncherTheme.DARK }
    }
    val themeFlow: Flow<LauncherTheme> = selectedTheme

    suspend fun setSelectedTheme(theme: LauncherTheme) {
        context.dataStore.edit { it[SELECTED_THEME] = theme.name }
    }
    suspend fun setTheme(theme: LauncherTheme) = setSelectedTheme(theme)

    // ── Clock Style ────────────────────────────────────────────────────
    val clockStyle: Flow<ClockStyle> = context.dataStore.data.map { prefs ->
        val name = prefs[CLOCK_STYLE] ?: ClockStyle.LARGE_MINIMAL.name
        try { ClockStyle.valueOf(name) } catch (_: Exception) { ClockStyle.LARGE_MINIMAL }
    }
    val clockStyleFlow: Flow<ClockStyle> = clockStyle

    suspend fun setClockStyle(style: ClockStyle) {
        context.dataStore.edit { it[CLOCK_STYLE] = style.name }
    }

    // ── Text Alignment ─────────────────────────────────────────────────
    val textAlignment: Flow<TextAlignment> = context.dataStore.data.map { prefs ->
        val name = prefs[TEXT_ALIGNMENT] ?: TextAlignment.LEFT.name
        try { TextAlignment.valueOf(name) } catch (_: Exception) { TextAlignment.LEFT }
    }
    val textAlignmentFlow: Flow<TextAlignment> = textAlignment

    suspend fun setTextAlignment(alignment: TextAlignment) {
        context.dataStore.edit { it[TEXT_ALIGNMENT] = alignment.name }
    }

    // ── Favorite Apps ──────────────────────────────────────────────────
    val favoriteApps: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[FAVORITE_APPS] ?: emptySet()
    }
    val favoriteAppsFlow: Flow<Set<String>> = favoriteApps

    suspend fun setFavoriteApps(apps: Set<String>) {
        context.dataStore.edit { it[FAVORITE_APPS] = apps }
    }

    suspend fun toggleFavorite(packageName: String) {
        val current = favoriteApps.first()
        val updated = if (packageName in current) current - packageName else current + packageName
        setFavoriteApps(updated)
    }

    // ── Hidden Apps ────────────────────────────────────────────────────
    val hiddenApps: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[HIDDEN_APPS] ?: emptySet()
    }
    val hiddenAppsFlow: Flow<Set<String>> = hiddenApps

    suspend fun setHiddenApps(apps: Set<String>) {
        context.dataStore.edit { it[HIDDEN_APPS] = apps }
    }

    suspend fun toggleHidden(packageName: String) {
        val current = hiddenApps.first()
        val updated = if (packageName in current) current - packageName else current + packageName
        setHiddenApps(updated)
    }

    // ── Custom App Labels ──────────────────────────────────────────────
    val customAppLabels: Flow<Map<String, String>> = context.dataStore.data.map { prefs ->
        val json = prefs[CUSTOM_APP_LABELS] ?: "{}"
        try {
            val jsonObject = JSONObject(json)
            buildMap {
                jsonObject.keys().forEach { key ->
                    put(key, jsonObject.getString(key))
                }
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }
    val appRenamesFlow: Flow<Map<String, String>> = customAppLabels

    suspend fun setCustomAppLabels(labels: Map<String, String>) {
        val jsonObject = JSONObject()
        labels.forEach { (key, value) -> jsonObject.put(key, value) }
        context.dataStore.edit { it[CUSTOM_APP_LABELS] = jsonObject.toString() }
    }

    suspend fun renameApp(packageName: String, newLabel: String) {
        val current = customAppLabels.first().toMutableMap()
        if (newLabel.isBlank()) {
            current.remove(packageName)
        } else {
            current[packageName] = newLabel
        }
        setCustomAppLabels(current)
    }

    // ── Font Scale ─────────────────────────────────────────────────────
    val fontScale: Flow<Float> = context.dataStore.data.map { prefs ->
        prefs[FONT_SCALE] ?: 1.0f
    }
    val fontScaleFlow: Flow<Float> = fontScale

    suspend fun setFontScale(scale: Float) {
        context.dataStore.edit { it[FONT_SCALE] = scale }
    }

    // ── Show Calendar ──────────────────────────────────────────────────
    val showCalendar: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[SHOW_CALENDAR] ?: true
    }
    val showCalendarFlow: Flow<Boolean> = showCalendar

    suspend fun setShowCalendar(show: Boolean) {
        context.dataStore.edit { it[SHOW_CALENDAR] = show }
    }

    // ── Show Widget Stack ──────────────────────────────────────────────
    val showWidgetStack: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[SHOW_WIDGET_STACK] ?: true
    }
    val showWidgetStackFlow: Flow<Boolean> = showWidgetStack

    suspend fun setShowWidgetStack(show: Boolean) {
        context.dataStore.edit { it[SHOW_WIDGET_STACK] = show }
    }

    // ── Home Screen App Count ──────────────────────────────────────────
    val homeScreenAppCount: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[HOME_SCREEN_APP_COUNT] ?: 8
    }
    val homeAppCountFlow: Flow<Int> = homeScreenAppCount

    suspend fun setHomeScreenAppCount(count: Int) {
        context.dataStore.edit { it[HOME_SCREEN_APP_COUNT] = count }
    }
    suspend fun setHomeAppCount(count: Int) = setHomeScreenAppCount(count)

    // ── Double Tap to Lock ─────────────────────────────────────────────
    val doubleTapToLock: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[DOUBLE_TAP_TO_LOCK] ?: false
    }
    val doubleTapToLockFlow: Flow<Boolean> = doubleTapToLock

    suspend fun setDoubleTapToLock(enabled: Boolean) {
        context.dataStore.edit { it[DOUBLE_TAP_TO_LOCK] = enabled }
    }

    // ── Swipe Down for Notifications ───────────────────────────────────
    val swipeDownForNotifications: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[SWIPE_DOWN_FOR_NOTIFICATIONS] ?: true
    }
    val swipeDownForNotificationsFlow: Flow<Boolean> = swipeDownForNotifications

    suspend fun setSwipeDownForNotifications(enabled: Boolean) {
        context.dataStore.edit { it[SWIPE_DOWN_FOR_NOTIFICATIONS] = enabled }
    }
}
