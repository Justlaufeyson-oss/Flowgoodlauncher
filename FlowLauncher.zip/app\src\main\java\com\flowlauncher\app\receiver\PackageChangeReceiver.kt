package com.flowlauncher.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

class PackageChangeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        val packageName = intent?.data?.schemeSpecificPart
        if (packageName != null) {
            _packageChanges.tryEmit(packageName)
        }
    }

    companion object {
        private val _packageChanges = MutableSharedFlow<String>(extraBufferCapacity = 10)
        val packageChanges = _packageChanges.asSharedFlow()
    }
}
