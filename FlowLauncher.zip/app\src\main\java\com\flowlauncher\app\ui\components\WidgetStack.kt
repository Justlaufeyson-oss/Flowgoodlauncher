package com.flowlauncher.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DoNotDisturb
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Pop-up widget stack panel that slides in from the right edge.
 *
 * Contains expandable widget cards for Quick Notes, Media Controls,
 * Screen Time, Quick Toggles, and Contacts. Each card uses spring-based
 * animations for expand/collapse. The entire panel can be dismissed
 * by swiping right or tapping outside.
 */
@Composable
fun WidgetStack(
    isVisible: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn(
            animationSpec = spring(stiffness = Spring.StiffnessMedium)
        ),
        exit = fadeOut(
            animationSpec = spring(stiffness = Spring.StiffnessMedium)
        )
    ) {
        Box(
            modifier = modifier.fillMaxSize()
        ) {
            // Scrim background - tap to dismiss
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = onDismiss
                    )
            )

            // Sliding panel
            WidgetPanel(onDismiss = onDismiss)
        }
    }
}

/**
 * The actual panel that slides in from the right containing the widget cards.
 */
@Composable
private fun WidgetPanel(
    onDismiss: () -> Unit
) {
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current
    val dismissThreshold = with(density) { 120.dp.toPx() }

    val animatedOffset by animateFloatAsState(
        targetValue = dragOffset,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "panelOffset"
    )

    AnimatedVisibility(
        visible = true,
        enter = slideInHorizontally(
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            initialOffsetX = { it }
        ),
        exit = slideOutHorizontally(
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMedium
            ),
            targetOffsetX = { it }
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.85f)
                .offset { IntOffset(animatedOffset.roundToInt().coerceAtLeast(0), 0) }
                .align(Alignment.CenterEnd)
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        dragOffset = (dragOffset + delta).coerceAtLeast(0f)
                    },
                    onDragStopped = {
                        if (dragOffset > dismissThreshold) {
                            onDismiss()
                        }
                        dragOffset = 0f
                    }
                )
                .clip(RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF1A1A2E).copy(alpha = 0.95f),
                            Color(0xFF16213E).copy(alpha = 0.95f)
                        )
                    )
                )
                .padding(top = 48.dp, bottom = 24.dp)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "Widgets",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White.copy(alpha = 0.85f),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                    )
                }

                item { QuickNotesWidget() }
                item { MediaControlsWidget() }
                item { ScreenTimeWidget() }
                item { QuickTogglesWidget() }
                item { ContactsWidget() }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }
}

// ─── Expandable Card Container ───────────────────────────────────────────────

/**
 * Reusable expandable widget card with header, collapse/expand chevron,
 * and spring-animated content area.
 */
@Composable
private fun WidgetCard(
    title: String,
    initiallyExpanded: Boolean = true,
    content: @Composable () -> Unit
) {
    var isExpanded by rememberSaveable { mutableStateOf(initiallyExpanded) }

    val chevronRotation by animateFloatAsState(
        targetValue = if (isExpanded) 180f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardChevron"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.07f))
            .animateContentSize(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { isExpanded = !isExpanded }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = Color.White.copy(alpha = 0.85f),
                fontWeight = FontWeight.SemiBold
            )

            Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = if (isExpanded) "Collapse" else "Expand",
                tint = Color.White.copy(alpha = 0.4f),
                modifier = Modifier
                    .size(20.dp)
                    .rotate(chevronRotation)
            )
        }

        // Content
        if (isExpanded) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
            ) {
                content()
            }
        }
    }
}

// ─── Quick Notes Widget ──────────────────────────────────────────────────────

@Composable
private fun QuickNotesWidget() {
    WidgetCard(title = "Quick Notes") {
        var noteText by rememberSaveable { mutableStateOf("") }

        BasicTextField(
            value = noteText,
            onValueChange = { noteText = it },
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.05f))
                .padding(12.dp),
            textStyle = TextStyle(
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 14.sp
            ),
            cursorBrush = SolidColor(Color.White.copy(alpha = 0.6f)),
            decorationBox = { innerTextField ->
                Box {
                    if (noteText.isEmpty()) {
                        Text(
                            text = "Jot something down...",
                            style = TextStyle(
                                color = Color.White.copy(alpha = 0.3f),
                                fontSize = 14.sp
                            )
                        )
                    }
                    innerTextField()
                }
            }
        )
    }
}

// ─── Media Controls Widget ───────────────────────────────────────────────────

@Composable
private fun MediaControlsWidget() {
    WidgetCard(title = "Media Controls", initiallyExpanded = false) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Track info
            Text(
                text = "No media playing",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.6f),
                fontWeight = FontWeight.Medium
            )

            Text(
                text = "Open a media app to see controls",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.3f)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Playback controls row
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MediaButton(
                    icon = Icons.Default.SkipPrevious,
                    contentDescription = "Previous",
                    size = 36
                )
                MediaButton(
                    icon = Icons.Default.PlayArrow,
                    contentDescription = "Play",
                    size = 48,
                    isPrimary = true
                )
                MediaButton(
                    icon = Icons.Default.SkipNext,
                    contentDescription = "Next",
                    size = 36
                )
            }
        }
    }
}

@Composable
private fun MediaButton(
    icon: ImageVector,
    contentDescription: String,
    size: Int,
    isPrimary: Boolean = false
) {
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(
                if (isPrimary) Color.White.copy(alpha = 0.15f)
                else Color.Transparent
            )
            .clickable { /* Placeholder */ },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = Color.White.copy(alpha = if (isPrimary) 0.9f else 0.5f),
            modifier = Modifier.size((size * 0.55f).dp)
        )
    }
}

// ─── Screen Time Widget ──────────────────────────────────────────────────────

@Composable
private fun ScreenTimeWidget() {
    WidgetCard(title = "Screen Time", initiallyExpanded = false) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Circular progress indicator
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(64.dp)
            ) {
                CircularProgressIndicator(
                    progress = { 0.45f },
                    modifier = Modifier.size(64.dp),
                    color = Color(0xFF7C4DFF),
                    trackColor = Color.White.copy(alpha = 0.08f),
                    strokeWidth = 5.dp,
                    strokeCap = StrokeCap.Round
                )

                Text(
                    text = "3h 24m",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.8f),
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }

            Column {
                Text(
                    text = "Today's Usage",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.7f),
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "45% of daily goal",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.4f)
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "12% less than yesterday",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF69F0AE).copy(alpha = 0.7f),
                    fontSize = 11.sp
                )
            }
        }
    }
}

// ─── Quick Toggles Widget ────────────────────────────────────────────────────

@Composable
private fun QuickTogglesWidget() {
    WidgetCard(title = "Quick Toggles") {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ToggleButton(
                icon = Icons.Default.Wifi,
                label = "WiFi",
                isActive = true
            )
            ToggleButton(
                icon = Icons.Default.Bluetooth,
                label = "BT",
                isActive = false
            )
            ToggleButton(
                icon = Icons.Default.FlashlightOn,
                label = "Flash",
                isActive = false
            )
            ToggleButton(
                icon = Icons.Default.DoNotDisturb,
                label = "DND",
                isActive = false
            )
        }
    }
}

@Composable
private fun ToggleButton(
    icon: ImageVector,
    label: String,
    isActive: Boolean
) {
    var toggled by remember { mutableStateOf(isActive) }

    val bgAlpha by animateFloatAsState(
        targetValue = if (toggled) 0.2f else 0.06f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "toggleBg"
    )

    val iconAlpha by animateFloatAsState(
        targetValue = if (toggled) 0.95f else 0.4f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "toggleIcon"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { toggled = !toggled }
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(
                    if (toggled) Color(0xFF4FC3F7).copy(alpha = bgAlpha)
                    else Color.White.copy(alpha = bgAlpha)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (toggled) Color(0xFF4FC3F7).copy(alpha = iconAlpha)
                else Color.White.copy(alpha = iconAlpha),
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(alpha = if (toggled) 0.7f else 0.35f),
            fontSize = 10.sp
        )
    }
}

// ─── Contacts Widget ─────────────────────────────────────────────────────────

@Composable
private fun ContactsWidget() {
    WidgetCard(title = "Contacts", initiallyExpanded = false) {
        val contacts = listOf("Alice", "Bob", "Carol", "Dave", "Eve")

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            contacts.forEach { name ->
                ContactRow(name = name)
            }
        }
    }
}

@Composable
private fun ContactRow(name: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.04f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar placeholder
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF6366F1).copy(alpha = 0.6f),
                            Color(0xFF8B5CF6).copy(alpha = 0.6f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Text(
            text = name,
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.75f),
            modifier = Modifier.weight(1f)
        )

        // Action buttons
        IconButton(
            onClick = { /* Open dialer */ },
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Call,
                contentDescription = "Call $name",
                tint = Color(0xFF69F0AE).copy(alpha = 0.7f),
                modifier = Modifier.size(16.dp)
            )
        }

        Spacer(modifier = Modifier.width(4.dp))

        IconButton(
            onClick = { /* Open messages */ },
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Message,
                contentDescription = "Message $name",
                tint = Color(0xFF4FC3F7).copy(alpha = 0.7f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
