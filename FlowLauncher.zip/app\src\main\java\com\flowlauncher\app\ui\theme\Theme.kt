package com.flowlauncher.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.flowlauncher.app.model.LauncherTheme

private fun launcherThemeToColorScheme(theme: LauncherTheme): ColorScheme {
    val primary = Color(theme.primaryColor)
    val secondary = Color(theme.secondaryColor)
    val background = Color(theme.backgroundColor)
    val surface = Color(theme.surfaceColor)
    val onText = Color(theme.textColor)

    val isLight = theme == LauncherTheme.LIGHT

    return if (isLight) {
        lightColorScheme(
            primary = primary,
            onPrimary = Color.White,
            primaryContainer = primary.copy(alpha = 0.12f),
            onPrimaryContainer = primary,
            secondary = secondary,
            onSecondary = Color.White,
            secondaryContainer = secondary.copy(alpha = 0.12f),
            onSecondaryContainer = secondary,
            tertiary = secondary,
            background = background,
            onBackground = onText,
            surface = surface,
            onSurface = onText,
            surfaceVariant = surface.copy(alpha = 0.8f),
            onSurfaceVariant = onText.copy(alpha = 0.7f),
            outline = onText.copy(alpha = 0.2f),
            outlineVariant = onText.copy(alpha = 0.1f),
            inverseSurface = Color(0xFF303030),
            inverseOnSurface = Color(0xFFF0F0F0),
            inversePrimary = primary.copy(alpha = 0.8f),
            surfaceTint = primary
        )
    } else {
        darkColorScheme(
            primary = primary,
            onPrimary = Color.Black,
            primaryContainer = primary.copy(alpha = 0.15f),
            onPrimaryContainer = primary,
            secondary = secondary,
            onSecondary = Color.Black,
            secondaryContainer = secondary.copy(alpha = 0.15f),
            onSecondaryContainer = secondary,
            tertiary = secondary,
            background = background,
            onBackground = onText,
            surface = surface,
            onSurface = onText,
            surfaceVariant = surface.copy(alpha = 0.8f),
            onSurfaceVariant = onText.copy(alpha = 0.7f),
            outline = onText.copy(alpha = 0.2f),
            outlineVariant = onText.copy(alpha = 0.1f),
            inverseSurface = Color(0xFFE0E0E0),
            inverseOnSurface = Color(0xFF303030),
            inversePrimary = primary.copy(alpha = 0.8f),
            surfaceTint = primary
        )
    }
}

@Composable
fun FlowLauncherTheme(
    theme: LauncherTheme = LauncherTheme.DARK,
    fontScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val colorScheme = launcherThemeToColorScheme(theme)
    val typography = scaledTypography(fontScale)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        content = content
    )
}
