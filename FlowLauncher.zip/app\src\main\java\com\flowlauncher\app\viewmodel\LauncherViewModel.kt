package com.flowlauncher.app.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.flowlauncher.app.data.AppRepository
import com.flowlauncher.app.data.PreferencesManager
import com.flowlauncher.app.model.*
import com.flowlauncher.app.receiver.PackageChangeReceiver
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val preferencesManager = PreferencesManager(application)

    // ── Raw & filtered apps ──────────────────────────────────────────────────
    private val _allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val allApps: StateFlow<List<AppInfo>> = _allApps.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isAppDrawerOpen = MutableStateFlow(false)
    val isAppDrawerOpen: StateFlow<Boolean> = _isAppDrawerOpen.asStateFlow()

    private val _isSearchActive = MutableStateFlow(false)
    val isSearchActive: StateFlow<Boolean> = _isSearchActive.asStateFlow()

    private val _isWidgetStackOpen = MutableStateFlow(false)
    val isWidgetStackOpen: StateFlow<Boolean> = _isWidgetStackOpen.asStateFlow()

    private val _calendarEvents = MutableStateFlow<List<CalendarEvent>>(emptyList())
    val calendarEvents: StateFlow<List<CalendarEvent>> = _calendarEvents.asStateFlow()

    private val _appToRename = MutableStateFlow<AppInfo?>(null)
    val appToRename: StateFlow<AppInfo?> = _appToRename.asStateFlow()

    // ── Preferences flows ────────────────────────────────────────────────────
    val selectedTheme: StateFlow<LauncherTheme> = preferencesManager.selectedTheme
        .stateIn(viewModelScope, SharingStarted.Eagerly, LauncherTheme.DARK)
    val theme: StateFlow<LauncherTheme> = selectedTheme

    val clockStyle: StateFlow<ClockStyle> = preferencesManager.clockStyle
        .stateIn(viewModelScope, SharingStarted.Eagerly, ClockStyle.LARGE_MINIMAL)

    val textAlignment: StateFlow<TextAlignment> = preferencesManager.textAlignment
        .stateIn(viewModelScope, SharingStarted.Eagerly, TextAlignment.LEFT)

    val fontScale: StateFlow<Float> = preferencesManager.fontScale
        .stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)

    val showCalendar: StateFlow<Boolean> = preferencesManager.showCalendar
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    val showWidgetStack: StateFlow<Boolean> = preferencesManager.showWidgetStack
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    val homeAppCount: StateFlow<Int> = preferencesManager.homeScreenAppCount
        .stateIn(viewModelScope, SharingStarted.Eagerly, 8)

    val favoritePackageNames: StateFlow<Set<String>> = preferencesManager.favoriteApps
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val favoritePackages: StateFlow<Set<String>> = favoritePackageNames

    val hiddenPackages: StateFlow<Set<String>> = preferencesManager.hiddenApps
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val appRenames: StateFlow<Map<String, String>> = preferencesManager.customAppLabels
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val doubleTapToLock: StateFlow<Boolean> = preferencesManager.doubleTapToLock
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val swipeDownNotifications: StateFlow<Boolean> = preferencesManager.swipeDownForNotifications
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    // ── Derived App Lists ────────────────────────────────────────────────────
    val favoriteApps: StateFlow<List<AppInfo>> = combine(
        _allApps, favoritePackageNames, appRenames, homeAppCount
    ) { apps, favPkgs, renames, maxCount ->
        apps.filter { it.packageName in favPkgs }
            .map { app ->
                app.copy(
                    isFavorite = true,
                    customLabel = renames[app.packageName]
                )
            }
            .sortedBy { it.displayLabel.lowercase() }
            .take(maxCount)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val visibleApps: StateFlow<List<AppInfo>> = combine(
        _allApps, hiddenPackages, appRenames
    ) { apps, hidden, renames ->
        apps.filter { it.packageName !in hidden }
            .map { app ->
                app.copy(customLabel = renames[app.packageName])
            }
            .sortedBy { it.displayLabel.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val filteredApps: StateFlow<List<AppInfo>> = combine(
        visibleApps, _searchQuery
    ) { apps, query ->
        AppRepository.searchApps(apps, query)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        loadApps()
        loadCalendarEvents()
        observePackageChanges()
    }

    // ── Actions ──────────────────────────────────────────────────────────────
    fun loadApps() {
        val context = getApplication<Application>()
        val apps = AppRepository.loadInstalledApps(context)
        _allApps.value = apps
    }

    fun loadCalendarEvents() {
        val context = getApplication<Application>()
        val events = AppRepository.loadCalendarEvents(context, daysAhead = 3)
        _calendarEvents.value = events
    }

    private fun observePackageChanges() {
        viewModelScope.launch {
            PackageChangeReceiver.packageChanges.collect {
                loadApps()
            }
        }
    }

    fun openAppDrawer() {
        _isAppDrawerOpen.value = true
    }

    fun closeAppDrawer() {
        _isAppDrawerOpen.value = false
        _searchQuery.value = ""
        _isSearchActive.value = false
    }

    fun toggleAppDrawer() {
        if (_isAppDrawerOpen.value) closeAppDrawer() else openAppDrawer()
    }

    fun setSearchActive(active: Boolean) {
        _isSearchActive.value = active
        if (!active) _searchQuery.value = ""
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openWidgetStack() {
        _isWidgetStackOpen.value = true
    }

    fun closeWidgetStack() {
        _isWidgetStackOpen.value = false
    }

    fun toggleWidgetStack() {
        _isWidgetStackOpen.value = !_isWidgetStackOpen.value
    }

    fun resetHomeState() {
        closeAppDrawer()
        closeWidgetStack()
        setSearchActive(false)
    }

    fun launchApp(context: Context, packageName: String) {
        val intent = AppRepository.getLaunchIntent(context, packageName)
        intent?.let { context.startActivity(it) }
    }

    fun launchApp(packageName: String) {
        val context = getApplication<Application>()
        launchApp(context, packageName)
    }

    // ── Favorites & Customization ────────────────────────────────────────────
    fun addToFavorites(app: AppInfo) {
        viewModelScope.launch {
            val current = favoritePackageNames.value
            preferencesManager.setFavoriteApps(current + app.packageName)
        }
    }

    fun removeFromFavorites(app: AppInfo) {
        viewModelScope.launch {
            val current = favoritePackageNames.value
            preferencesManager.setFavoriteApps(current - app.packageName)
        }
    }

    fun toggleFavorite(packageName: String) {
        viewModelScope.launch { preferencesManager.toggleFavorite(packageName) }
    }

    fun hideApp(app: AppInfo) {
        viewModelScope.launch {
            val current = hiddenPackages.value
            preferencesManager.setHiddenApps(current + app.packageName)
        }
    }

    fun unhideApp(packageName: String) {
        viewModelScope.launch {
            val current = hiddenPackages.value
            preferencesManager.setHiddenApps(current - packageName)
        }
    }

    fun toggleHidden(packageName: String) {
        viewModelScope.launch { preferencesManager.toggleHidden(packageName) }
    }

    fun requestRename(app: AppInfo) {
        _appToRename.value = app
    }

    fun dismissRename() {
        _appToRename.value = null
    }

    fun renameApp(packageName: String, newLabel: String) {
        viewModelScope.launch {
            preferencesManager.renameApp(packageName, newLabel)
            _appToRename.value = null
        }
    }

    // ── Settings ─────────────────────────────────────────────────────────────
    fun setTheme(theme: LauncherTheme) {
        viewModelScope.launch { preferencesManager.setSelectedTheme(theme) }
    }

    fun setClockStyle(style: ClockStyle) {
        viewModelScope.launch { preferencesManager.setClockStyle(style) }
    }

    fun setTextAlignment(alignment: TextAlignment) {
        viewModelScope.launch { preferencesManager.setTextAlignment(alignment) }
    }

    fun setFontScale(scale: Float) {
        viewModelScope.launch { preferencesManager.setFontScale(scale) }
    }

    fun setShowCalendar(show: Boolean) {
        viewModelScope.launch { preferencesManager.setShowCalendar(show) }
    }

    fun setShowWidgetStack(show: Boolean) {
        viewModelScope.launch { preferencesManager.setShowWidgetStack(show) }
    }

    fun setHomeAppCount(count: Int) {
        viewModelScope.launch { preferencesManager.setHomeScreenAppCount(count) }
    }

    fun setDoubleTapToLock(enabled: Boolean) {
        viewModelScope.launch { preferencesManager.setDoubleTapToLock(enabled) }
    }

    fun setSwipeDownNotifications(enabled: Boolean) {
        viewModelScope.launch { preferencesManager.setSwipeDownForNotifications(enabled) }
    }
}
