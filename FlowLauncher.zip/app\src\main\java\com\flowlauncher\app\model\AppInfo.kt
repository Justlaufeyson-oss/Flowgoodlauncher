package com.flowlauncher.app.model

import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds

data class AppInfo(
    val packageName: String,
    val label: String,
    val isSystemApp: Boolean,
    val isFavorite: Boolean = false,
    val favoriteIndex: Int = -1,
    val customLabel: String? = null,
    val isHidden: Boolean = false,
    val componentName: String? = null
) {
    val displayLabel: String
        get() = customLabel?.takeIf { it.isNotBlank() } ?: label

    val displayName: String
        get() = displayLabel
}

data class CalendarEvent(
    val id: Long,
    val title: String,
    val startTime: Long,
    val endTime: Long,
    val calendarColor: Int,
    val location: String? = null,
    val isAllDay: Boolean = false
) {
    val isOngoing: Boolean
        get() {
            val now = System.currentTimeMillis()
            return now in startTime..endTime
        }

    val timeUntilStart: Duration
        get() {
            val now = System.currentTimeMillis()
            return (startTime - now).coerceAtLeast(0L).milliseconds
        }
}

enum class LauncherTheme(
    val displayName: String,
    val primaryColor: Long,
    val secondaryColor: Long,
    val backgroundColor: Long,
    val surfaceColor: Long,
    val textColor: Long
) {
    DARK(
        displayName = "Dark",
        primaryColor = 0xFFBB86FC,
        secondaryColor = 0xFF03DAC6,
        backgroundColor = 0xFF121212,
        surfaceColor = 0xFF1E1E1E,
        textColor = 0xFFE0E0E0
    ),
    LIGHT(
        displayName = "Light",
        primaryColor = 0xFF6200EE,
        secondaryColor = 0xFF03DAC6,
        backgroundColor = 0xFFFAFAFA,
        surfaceColor = 0xFFFFFFFF,
        textColor = 0xFF212121
    ),
    AMOLED(
        displayName = "AMOLED",
        primaryColor = 0xFFBB86FC,
        secondaryColor = 0xFF03DAC6,
        backgroundColor = 0xFF000000,
        surfaceColor = 0xFF0A0A0A,
        textColor = 0xFFFFFFFF
    ),
    OCEAN(
        displayName = "Ocean",
        primaryColor = 0xFF64B5F6,
        secondaryColor = 0xFF4DD0E1,
        backgroundColor = 0xFF0D1B2A,
        surfaceColor = 0xFF1B2838,
        textColor = 0xFFE0E8F0
    ),
    SUNSET(
        displayName = "Sunset",
        primaryColor = 0xFFFF8A65,
        secondaryColor = 0xFFFFAB91,
        backgroundColor = 0xFF1A0E0A,
        surfaceColor = 0xFF2C1810,
        textColor = 0xFFFDE8D8
    ),
    FOREST(
        displayName = "Forest",
        primaryColor = 0xFF81C784,
        secondaryColor = 0xFFA5D6A7,
        backgroundColor = 0xFF0A1A0D,
        surfaceColor = 0xFF142B18,
        textColor = 0xFFD8ECD8
    ),
    ROSE(
        displayName = "Rose",
        primaryColor = 0xFFF48FB1,
        secondaryColor = 0xFFF8BBD0,
        backgroundColor = 0xFF1A0A12,
        surfaceColor = 0xFF2C1420,
        textColor = 0xFFFDE0EC
    )
}

enum class ClockStyle {
    LARGE_MINIMAL,
    DIGITAL_BOLD,
    ANALOG_CLEAN,
    DATE_FOCUSED,
    HIDDEN
}

enum class TextAlignment {
    LEFT,
    CENTER,
    RIGHT
}

data class WidgetInfo(
    val id: Int,
    val label: String,
    val icon: Int? = null,
    val isExpanded: Boolean = false
)
