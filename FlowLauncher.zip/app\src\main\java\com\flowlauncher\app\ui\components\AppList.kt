package com.flowlauncher.app.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.compose.ui.zIndex
import com.flowlauncher.app.viewmodel.LauncherViewModel
import com.flowlauncher.app.model.AppInfo
import kotlinx.coroutines.delay

// ─────────────────────────────────────────────────────
// Data models expected from the ViewModel / data layer
// ─────────────────────────────────────────────────────

/**
 * Represents an option in the long-press context menu.
 */
data class AppMenuOption(
    val label: String,
    val icon: ImageVector,
    val destructive: Boolean = false,
    val onClick: () -> Unit
)

// ─────────────────────────────────────────────────────
// FavoriteAppList – the home screen Niagara-style list
// ─────────────────────────────────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FavoriteAppList(
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier,
    onAppLaunch: (AppInfo) -> Unit = {},
    onOpenAppDrawer: () -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val favoriteApps by viewModel.favoriteApps.collectAsState()

    var selectedApp by remember { mutableStateOf<AppInfo?>(null) }
    var menuOffset by remember { mutableStateOf(Offset.Zero) }

    Box(modifier = modifier) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 24.dp, end = 64.dp, top = 8.dp, bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            itemsIndexed(
                items = favoriteApps,
                key = { _, app -> app.packageName }
            ) { index, app ->
                var appeared by remember { mutableStateOf(false) }

                LaunchedEffect(Unit) {
                    delay(index * 50L)
                    appeared = true
                }

                val animatedAlpha by animateFloatAsState(
                    targetValue = if (appeared) 1f else 0f,
                    animationSpec = tween(400, easing = EaseOutCubic),
                    label = "alpha_$index"
                )
                val animatedOffsetX by animateFloatAsState(
                    targetValue = if (appeared) 0f else -40f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    ),
                    label = "offsetX_$index"
                )

                var isPressed by remember { mutableStateOf(false) }
                val scale by animateFloatAsState(
                    targetValue = if (isPressed) 0.95f else 1f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    ),
                    label = "press_scale_$index"
                )

                Box(
                    modifier = Modifier
                        .graphicsLayer {
                            this.alpha = animatedAlpha
                            this.translationX = animatedOffsetX * density
                        }
                        .scale(scale)
                        .animateItemPlacement(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        )
                ) {
                    FavoriteAppRow(
                        app = app,
                        onTap = {
                            isPressed = true
                            launchApp(context, app)
                            onAppLaunch(app)
                        },
                        onLongPress = { offset ->
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            menuOffset = offset
                            selectedApp = app
                        },
                        onPressChange = { pressed -> isPressed = pressed }
                    )
                }
            }
        }

        // Context menu
        selectedApp?.let { app ->
            AppOptionMenu(
                app = app,
                isFavorite = true,
                onDismiss = { selectedApp = null },
                options = buildFavoriteMenuOptions(
                    app = app,
                    context = context,
                    viewModel = viewModel,
                    onDismiss = { selectedApp = null }
                )
            )
        }
    }
}

@Composable
private fun FavoriteAppRow(
    app: AppInfo,
    onTap: () -> Unit,
    onLongPress: (Offset) -> Unit,
    onPressChange: (Boolean) -> Unit
) {
    val textColor = MaterialTheme.colorScheme.onBackground

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(app.packageName) {
                detectTapGestures(
                    onPress = { offset ->
                        onPressChange(true)
                        val released = tryAwaitRelease()
                        onPressChange(false)
                    },
                    onTap = { onTap() },
                    onLongPress = { offset -> onLongPress(offset) }
                )
            }
            .padding(vertical = 10.dp)
    ) {
        Text(
            text = app.displayName,
            fontSize = 28.sp,
            fontWeight = FontWeight.Normal,
            color = textColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ─────────────────────────────────────────────────────
// FullAppList – the app drawer
// ─────────────────────────────────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FullAppList(
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier,
    searchQuery: String = "",
    listState: LazyListState = rememberLazyListState(),
    onAppLaunch: (AppInfo) -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val allApps by viewModel.allApps.collectAsState()
    val favoritePackages by viewModel.favoritePackageNames.collectAsState()

    var selectedApp by remember { mutableStateOf<AppInfo?>(null) }

    val filteredApps = remember(allApps, searchQuery) {
        if (searchQuery.isBlank()) {
            allApps
        } else {
            allApps.filter {
                it.displayName.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    val groupedApps = remember(filteredApps) {
        filteredApps
            .sortedBy { it.displayName.uppercase() }
            .groupBy { app ->
                val first = app.displayName.firstOrNull()?.uppercaseChar() ?: '#'
                if (first.isLetter()) first else '#'
            }
    }

    Box(modifier = modifier) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 56.dp, top = 8.dp, bottom = 80.dp)
        ) {
            groupedApps.forEach { (letter, apps) ->
                stickyHeader(key = "header_$letter") {
                    SectionHeader(letter = letter)
                }

                items(
                    items = apps,
                    key = { it.packageName }
                ) { app ->
                    var isPressed by remember { mutableStateOf(false) }
                    val scale by animateFloatAsState(
                        targetValue = if (isPressed) 0.97f else 1f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "app_press_scale"
                    )

                    Box(
                        modifier = Modifier
                            .scale(scale)
                            .animateItemPlacement(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessMediumLow
                                )
                            )
                    ) {
                        AppDrawerRow(
                            app = app,
                            searchQuery = searchQuery,
                            onTap = {
                                isPressed = true
                                launchApp(context, app)
                                onAppLaunch(app)
                            },
                            onLongPress = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                selectedApp = app
                            },
                            onPressChange = { pressed -> isPressed = pressed }
                        )
                    }
                }
            }
        }

        // Alphabet scroller integration
        val availableLetters = remember(groupedApps) {
            groupedApps.keys.toSet()
        }

        val currentLetter by remember {
            derivedStateOf {
                val firstVisibleIndex = listState.firstVisibleItemIndex
                val keys = listState.layoutInfo.visibleItemsInfo.firstOrNull()?.key?.toString()
                if (keys != null && keys.startsWith("header_") && keys.length > 7) {
                    keys[7]
                } else {
                    groupedApps.keys.firstOrNull() ?: 'A'
                }
            }
        }

        AlphabetScroller(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .padding(vertical = 48.dp),
            availableLetters = availableLetters,
            currentLetter = currentLetter,
            onLetterSelected = { letter ->
                val headerKey = "header_$letter"
                val index = listState.layoutInfo.totalItemsCount.let {
                    // Find index of the header
                    var targetIndex = 0
                    var currentIndex = 0
                    for ((key, apps) in groupedApps) {
                        if (key == letter) {
                            targetIndex = currentIndex
                            break
                        }
                        currentIndex += 1 + apps.size // header + items
                    }
                    targetIndex
                }
                kotlinx.coroutines.MainScope().launch {
                    listState.animateScrollToItem(index)
                }
            }
        )

        // Context menu
        selectedApp?.let { app ->
            val isFav = favoritePackages.contains(app.packageName)
            AppOptionMenu(
                app = app,
                isFavorite = isFav,
                onDismiss = { selectedApp = null },
                options = buildDrawerMenuOptions(
                    app = app,
                    isFavorite = isFav,
                    context = context,
                    viewModel = viewModel,
                    onDismiss = { selectedApp = null }
                )
            )
        }
    }
}

@Composable
private fun SectionHeader(letter: Char) {
    val primaryColor = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.95f))
            .padding(vertical = 8.dp, horizontal = 4.dp)
    ) {
        Text(
            text = letter.toString(),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = primaryColor,
            letterSpacing = 2.sp
        )
    }
}

@Composable
private fun AppDrawerRow(
    app: AppInfo,
    searchQuery: String,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    onPressChange: (Boolean) -> Unit
) {
    val textColor = MaterialTheme.colorScheme.onBackground
    val highlightColor = MaterialTheme.colorScheme.primary

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(app.packageName) {
                detectTapGestures(
                    onPress = {
                        onPressChange(true)
                        val released = tryAwaitRelease()
                        onPressChange(false)
                    },
                    onTap = { onTap() },
                    onLongPress = { onLongPress() }
                )
            }
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // App icon
        if (app.icon != null) {
            Image(
                bitmap = app.icon,
                contentDescription = app.displayName,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
            )
        } else {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = app.displayName.firstOrNull()?.uppercase() ?: "?",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // App name with search highlight
        if (searchQuery.isNotBlank()) {
            Text(
                text = buildHighlightedText(app.displayName, searchQuery, textColor, highlightColor),
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        } else {
            Text(
                text = app.displayName,
                fontSize = 16.sp,
                fontWeight = FontWeight.Normal,
                color = textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun buildHighlightedText(
    text: String,
    query: String,
    textColor: Color,
    highlightColor: Color
) = buildAnnotatedString {
    var startIndex = 0
    val lowerText = text.lowercase()
    val lowerQuery = query.lowercase()

    while (startIndex < text.length) {
        val matchIndex = lowerText.indexOf(lowerQuery, startIndex)
        if (matchIndex == -1) {
            withStyle(SpanStyle(color = textColor)) {
                append(text.substring(startIndex))
            }
            break
        }
        if (matchIndex > startIndex) {
            withStyle(SpanStyle(color = textColor)) {
                append(text.substring(startIndex, matchIndex))
            }
        }
        withStyle(
            SpanStyle(
                color = highlightColor,
                fontWeight = FontWeight.Bold
            )
        ) {
            append(text.substring(matchIndex, matchIndex + lowerQuery.length))
        }
        startIndex = matchIndex + lowerQuery.length
    }
}

// ─────────────────────────────────────────────────────
// AppOptionMenu – context menu for long press
// ─────────────────────────────────────────────────────

@Composable
fun AppOptionMenu(
    app: AppInfo,
    isFavorite: Boolean,
    onDismiss: () -> Unit,
    options: List<AppMenuOption>
) {
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        visible = true
    }

    val scrimAlpha by animateFloatAsState(
        targetValue = if (visible) 0.5f else 0f,
        animationSpec = tween(250, easing = EaseOutCubic),
        label = "scrim_alpha"
    )

    val menuScale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.8f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "menu_scale"
    )

    val menuAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(200, easing = EaseOutCubic),
        label = "menu_alpha"
    )

    // Full-screen scrim
    Box(
        modifier = Modifier
            .fillMaxSize()
            .zIndex(100f)
            .background(Color.Black.copy(alpha = scrimAlpha))
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                visible = false
                onDismiss()
            },
        contentAlignment = Alignment.Center
    ) {
        // Menu card
        Card(
            modifier = Modifier
                .widthIn(min = 240.dp, max = 300.dp)
                .graphicsLayer {
                    this.scaleX = menuScale
                    this.scaleY = menuScale
                    this.alpha = menuAlpha
                }
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { /* Prevent clicks from passing through */ },
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                // App name header
                Text(
                    text = app.displayName,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                )

                HorizontalDivider(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )

                Spacer(modifier = Modifier.height(4.dp))

                options.forEachIndexed { index, option ->
                    var itemVisible by remember { mutableStateOf(false) }

                    LaunchedEffect(Unit) {
                        delay(index * 40L)
                        itemVisible = true
                    }

                    val itemAlpha by animateFloatAsState(
                        targetValue = if (itemVisible) 1f else 0f,
                        animationSpec = tween(200, easing = EaseOutCubic),
                        label = "item_alpha_$index"
                    )
                    val itemOffset by animateFloatAsState(
                        targetValue = if (itemVisible) 0f else 12f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "item_offset_$index"
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .graphicsLayer {
                                this.alpha = itemAlpha
                                this.translationY = itemOffset * density
                            }
                            .clickable {
                                option.onClick()
                                onDismiss()
                            }
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            imageVector = option.icon,
                            contentDescription = option.label,
                            modifier = Modifier.size(20.dp),
                            tint = if (option.destructive) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        Text(
                            text = option.label,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Normal,
                            color = if (option.destructive) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}

// ─────────────────────────────────────────────────────
// Menu option builders
// ─────────────────────────────────────────────────────

private fun buildFavoriteMenuOptions(
    app: AppInfo,
    context: Context,
    viewModel: LauncherViewModel,
    onDismiss: () -> Unit
): List<AppMenuOption> = listOf(
    AppMenuOption(
        label = "Launch",
        icon = Icons.Outlined.Launch,
        onClick = { launchApp(context, app) }
    ),
    AppMenuOption(
        label = "Remove from Favorites",
        icon = Icons.Outlined.StarBorder,
        onClick = { viewModel.removeFromFavorites(app) }
    ),
    AppMenuOption(
        label = "Rename",
        icon = Icons.Outlined.Edit,
        onClick = { viewModel.requestRename(app) }
    ),
    AppMenuOption(
        label = "App Info",
        icon = Icons.Outlined.Info,
        onClick = { openAppInfo(context, app) }
    ),
    AppMenuOption(
        label = "Hide",
        icon = Icons.Outlined.VisibilityOff,
        onClick = { viewModel.hideApp(app) }
    ),
    AppMenuOption(
        label = "Uninstall",
        icon = Icons.Outlined.Delete,
        destructive = true,
        onClick = { uninstallApp(context, app) }
    )
)

private fun buildDrawerMenuOptions(
    app: AppInfo,
    isFavorite: Boolean,
    context: Context,
    viewModel: LauncherViewModel,
    onDismiss: () -> Unit
): List<AppMenuOption> = buildList {
    add(
        AppMenuOption(
            label = "Launch",
            icon = Icons.Outlined.Launch,
            onClick = { launchApp(context, app) }
        )
    )

    if (isFavorite) {
        add(
            AppMenuOption(
                label = "Remove from Favorites",
                icon = Icons.Outlined.StarBorder,
                onClick = { viewModel.removeFromFavorites(app) }
            )
        )
    } else {
        add(
            AppMenuOption(
                label = "Add to Favorites",
                icon = Icons.Outlined.Star,
                onClick = { viewModel.addToFavorites(app) }
            )
        )
    }

    add(
        AppMenuOption(
            label = "Rename",
            icon = Icons.Outlined.Edit,
            onClick = { viewModel.requestRename(app) }
        )
    )
    add(
        AppMenuOption(
            label = "App Info",
            icon = Icons.Outlined.Info,
            onClick = { openAppInfo(context, app) }
        )
    )
    add(
        AppMenuOption(
            label = "Hide",
            icon = Icons.Outlined.VisibilityOff,
            onClick = { viewModel.hideApp(app) }
        )
    )
    add(
        AppMenuOption(
            label = "Uninstall",
            icon = Icons.Outlined.Delete,
            destructive = true,
            onClick = { uninstallApp(context, app) }
        )
    )
}

// ─────────────────────────────────────────────────────
// Utility functions
// ─────────────────────────────────────────────────────

private fun launchApp(context: Context, app: AppInfo) {
    try {
        val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

private fun openAppInfo(context: Context, app: AppInfo) {
    try {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${app.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

private fun uninstallApp(context: Context, app: AppInfo) {
    try {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:${app.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
