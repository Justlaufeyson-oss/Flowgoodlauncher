package com.flowlauncher.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import com.flowlauncher.app.ui.navigation.FlowLauncherNavGraph
import com.flowlauncher.app.viewmodel.LauncherViewModel

class MainActivity : ComponentActivity() {

    private val launcherViewModel: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        // Show system wallpaper behind launcher activity
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            FlowLauncherNavGraph(viewModel = launcherViewModel)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Home button pressed while launcher is active: reset home state
        if (Intent.ACTION_MAIN == intent?.action && intent.hasCategory(Intent.CATEGORY_HOME)) {
            launcherViewModel.resetHomeState()
        }
    }

    override fun onResume() {
        super.onResume()
        launcherViewModel.loadCalendarEvents()
    }
}
