# Flow Launcher ProGuard Rules
-keepclassmembers class * extends androidx.lifecycle.ViewModel { <init>(...); }
-keep class com.flowlauncher.app.model.** { *; }
