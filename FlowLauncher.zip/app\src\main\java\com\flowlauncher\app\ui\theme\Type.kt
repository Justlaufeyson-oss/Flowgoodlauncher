package com.flowlauncher.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Default sans-serif font family for clean, minimal aesthetics.
 */
private val LauncherFontFamily = FontFamily.SansSerif

/**
 * Base typography for FlowLauncher.
 */
val FlowLauncherTypography = Typography(
    // Clock display – bold, commanding
    displayLarge = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Thin,
        fontSize = 96.sp,
        lineHeight = 104.sp,
        letterSpacing = (-1.5).sp
    ),
    displayMedium = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Light,
        fontSize = 60.sp,
        lineHeight = 68.sp,
        letterSpacing = (-0.5).sp
    ),
    displaySmall = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 48.sp,
        lineHeight = 56.sp,
        letterSpacing = 0.sp
    ),

    // Headline for clock
    headlineLarge = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 64.sp,
        lineHeight = 72.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 34.sp,
        lineHeight = 42.sp,
        letterSpacing = 0.sp
    ),
    headlineSmall = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 24.sp,
        lineHeight = 32.sp,
        letterSpacing = 0.sp
    ),

    // App names – clean, medium weight
    titleLarge = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp
    ),
    titleMedium = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.15.sp
    ),
    titleSmall = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),

    // Calendar events
    bodyLarge = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.25.sp
    ),
    bodySmall = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.4.sp
    ),

    // Alphabet scroller letters
    labelLarge = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    labelMedium = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    ),
    labelSmall = TextStyle(
        fontFamily = LauncherFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.5.sp
    )
)

/**
 * Returns a new [Typography] with all text sizes scaled by the given [scale] factor.
 *
 * @param scale multiplier for all font sizes (e.g., 1.0 = default, 1.2 = 20% larger)
 */
fun scaledTypography(scale: Float): Typography {
    val base = FlowLauncherTypography
    val s = scale.coerceIn(0.5f, 2.5f)

    return Typography(
        displayLarge = base.displayLarge.copy(
            fontSize = base.displayLarge.fontSize * s,
            lineHeight = base.displayLarge.lineHeight * s
        ),
        displayMedium = base.displayMedium.copy(
            fontSize = base.displayMedium.fontSize * s,
            lineHeight = base.displayMedium.lineHeight * s
        ),
        displaySmall = base.displaySmall.copy(
            fontSize = base.displaySmall.fontSize * s,
            lineHeight = base.displaySmall.lineHeight * s
        ),
        headlineLarge = base.headlineLarge.copy(
            fontSize = base.headlineLarge.fontSize * s,
            lineHeight = base.headlineLarge.lineHeight * s
        ),
        headlineMedium = base.headlineMedium.copy(
            fontSize = base.headlineMedium.fontSize * s,
            lineHeight = base.headlineMedium.lineHeight * s
        ),
        headlineSmall = base.headlineSmall.copy(
            fontSize = base.headlineSmall.fontSize * s,
            lineHeight = base.headlineSmall.lineHeight * s
        ),
        titleLarge = base.titleLarge.copy(
            fontSize = base.titleLarge.fontSize * s,
            lineHeight = base.titleLarge.lineHeight * s
        ),
        titleMedium = base.titleMedium.copy(
            fontSize = base.titleMedium.fontSize * s,
            lineHeight = base.titleMedium.lineHeight * s
        ),
        titleSmall = base.titleSmall.copy(
            fontSize = base.titleSmall.fontSize * s,
            lineHeight = base.titleSmall.lineHeight * s
        ),
        bodyLarge = base.bodyLarge.copy(
            fontSize = base.bodyLarge.fontSize * s,
            lineHeight = base.bodyLarge.lineHeight * s
        ),
        bodyMedium = base.bodyMedium.copy(
            fontSize = base.bodyMedium.fontSize * s,
            lineHeight = base.bodyMedium.lineHeight * s
        ),
        bodySmall = base.bodySmall.copy(
            fontSize = base.bodySmall.fontSize * s,
            lineHeight = base.bodySmall.lineHeight * s
        ),
        labelLarge = base.labelLarge.copy(
            fontSize = base.labelLarge.fontSize * s,
            lineHeight = base.labelLarge.lineHeight * s
        ),
        labelMedium = base.labelMedium.copy(
            fontSize = base.labelMedium.fontSize * s,
            lineHeight = base.labelMedium.lineHeight * s
        ),
        labelSmall = base.labelSmall.copy(
            fontSize = base.labelSmall.fontSize * s,
            lineHeight = base.labelSmall.lineHeight * s
        )
    )
}

/**
 * Utility to scale a TextStyle's fontSize and lineHeight by [scale].
 */
private operator fun androidx.compose.ui.unit.TextUnit.times(scale: Float): androidx.compose.ui.unit.TextUnit {
    return if (this.isSp) (this.value * scale).sp else this
}
