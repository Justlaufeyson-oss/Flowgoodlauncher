package com.flowlauncher.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Data class representing a calendar event.
 */
data class CalendarEvent(
    val id: Long,
    val title: String,
    val startTime: Long,
    val endTime: Long,
    val isAllDay: Boolean = false,
    val location: String? = null,
    val calendarColor: Color = Color(0xFF4285F4)
)

/**
 * Calendar agenda widget displayed on the home screen.
 *
 * Shows upcoming calendar events in a glass-morphism styled card.
 * Supports expand/collapse with smooth spring animations,
 * pulsing glow for ongoing events, and staggered item animations.
 */
@Composable
fun CalendarAgenda(
    events: List<CalendarEvent>,
    modifier: Modifier = Modifier,
    onEventClick: (CalendarEvent) -> Unit = {},
    maxVisibleEvents: Int = 4
) {
    var isExpanded by rememberSaveable { mutableStateOf(false) }

    val chevronRotation by animateFloatAsState(
        targetValue = if (isExpanded) 180f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "chevronRotation"
    )

    val visibleEvents = if (isExpanded) {
        events.take(maxVisibleEvents)
    } else {
        events.take(1)
    }

    val remainingCount = (events.size - maxVisibleEvents).coerceAtLeast(0)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.12f),
                        Color.White.copy(alpha = 0.06f)
                    )
                )
            )
            .clickable { isExpanded = !isExpanded }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .animateContentSize(
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    )
                )
        ) {
            // Header row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Upcoming",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White.copy(alpha = 0.6f),
                    letterSpacing = 1.sp
                )

                if (events.isNotEmpty()) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        tint = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier
                            .size(20.dp)
                            .rotate(chevronRotation)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (events.isEmpty()) {
                // Empty state
                EmptyAgendaState()
            } else {
                // Event list
                visibleEvents.forEachIndexed { index, event ->
                    AnimatedVisibility(
                        visible = true,
                        enter = slideInVertically(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioLowBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            ),
                            initialOffsetY = { it * (index + 1) }
                        ) + fadeIn(
                            animationSpec = spring(
                                stiffness = Spring.StiffnessMediumLow
                            )
                        ),
                        exit = slideOutVertically(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMedium
                            )
                        ) + fadeOut()
                    ) {
                        CalendarEventItem(
                            event = event,
                            onClick = { onEventClick(event) }
                        )
                    }

                    if (index < visibleEvents.lastIndex) {
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }

                // "N more events" indicator
                AnimatedVisibility(
                    visible = isExpanded && remainingCount > 0,
                    enter = fadeIn(
                        animationSpec = spring(stiffness = Spring.StiffnessLow)
                    ) + slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        ),
                        initialOffsetY = { it }
                    ),
                    exit = fadeOut() + slideOutVertically(
                        targetOffsetY = { it }
                    )
                ) {
                    Text(
                        text = "+$remainingCount more event${if (remainingCount > 1) "s" else ""}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.4f),
                        modifier = Modifier.padding(top = 8.dp, start = 20.dp)
                    )
                }
            }
        }
    }
}

/**
 * Individual calendar event row with colored indicator,
 * time info, and optional pulsing glow for ongoing events.
 */
@Composable
private fun CalendarEventItem(
    event: CalendarEvent,
    onClick: () -> Unit
) {
    val now = remember { System.currentTimeMillis() }
    val isOngoing = !event.isAllDay && event.startTime <= now && event.endTime > now

    // Pulsing glow for ongoing events
    val infiniteTransition = rememberInfiniteTransition(label = "ongoingPulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.45f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .then(
                if (isOngoing) {
                    Modifier.drawBehind {
                        drawRoundRect(
                            color = event.calendarColor.copy(alpha = glowAlpha),
                            cornerRadius = CornerRadius(12.dp.toPx())
                        )
                    }
                } else {
                    Modifier
                }
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Color indicator line
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(36.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(event.calendarColor)
        )

        Spacer(modifier = Modifier.width(12.dp))

        // Event info
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = event.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isOngoing) FontWeight.SemiBold else FontWeight.Normal,
                color = Color.White.copy(alpha = 0.9f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatEventTime(event),
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.55f)
                )

                if (isOngoing) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(event.calendarColor.copy(alpha = glowAlpha + 0.3f))
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Now",
                        style = MaterialTheme.typography.labelSmall,
                        color = event.calendarColor,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Location
            if (!event.location.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(1.dp))
                Text(
                    text = event.location,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.35f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Relative time badge
        Text(
            text = formatRelativeTime(event),
            style = MaterialTheme.typography.labelSmall,
            color = if (isOngoing) event.calendarColor else Color.White.copy(alpha = 0.4f),
            fontWeight = FontWeight.Medium,
            fontSize = 11.sp
        )
    }
}

/**
 * Empty state composable when there are no upcoming events.
 */
@Composable
private fun EmptyAgendaState() {
    val infiniteTransition = rememberInfiniteTransition(label = "emptyPulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "emptyAlpha"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "No upcoming events",
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = alpha),
            fontWeight = FontWeight.Light
        )
    }
}

/**
 * Formats the event time as a human-readable range.
 * E.g. "2:00 - 3:30 PM" or "All day"
 */
private fun formatEventTime(event: CalendarEvent): String {
    if (event.isAllDay) return "All day"

    val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
    val startFormatted = SimpleDateFormat("h:mm", Locale.getDefault()).format(Date(event.startTime))
    val endFormatted = timeFormat.format(Date(event.endTime))

    // If both AM or both PM, only show the suffix on the end
    val startCal = Calendar.getInstance().apply { timeInMillis = event.startTime }
    val endCal = Calendar.getInstance().apply { timeInMillis = event.endTime }

    return if (startCal.get(Calendar.AM_PM) == endCal.get(Calendar.AM_PM)) {
        "$startFormatted – $endFormatted"
    } else {
        "${timeFormat.format(Date(event.startTime))} – $endFormatted"
    }
}

/**
 * Formats the relative time until the event starts.
 * E.g. "in 30 min", "Tomorrow", "in 2 days", "Now"
 */
private fun formatRelativeTime(event: CalendarEvent): String {
    val now = System.currentTimeMillis()

    // Ongoing
    if (!event.isAllDay && event.startTime <= now && event.endTime > now) {
        return "Now"
    }

    val diffMs = event.startTime - now
    if (diffMs < 0) return "Past"

    val diffMinutes = TimeUnit.MILLISECONDS.toMinutes(diffMs)
    val diffHours = TimeUnit.MILLISECONDS.toHours(diffMs)
    val diffDays = TimeUnit.MILLISECONDS.toDays(diffMs)

    return when {
        diffMinutes < 1 -> "Now"
        diffMinutes < 60 -> "in ${diffMinutes}min"
        diffHours < 24 -> {
            val todayCal = Calendar.getInstance()
            val eventCal = Calendar.getInstance().apply { timeInMillis = event.startTime }
            if (todayCal.get(Calendar.DAY_OF_YEAR) != eventCal.get(Calendar.DAY_OF_YEAR)) {
                "Tomorrow"
            } else {
                "in ${diffHours}h"
            }
        }
        diffDays == 1L -> "Tomorrow"
        diffDays < 7 -> "in ${diffDays}d"
        else -> "in ${diffDays}d"
    }
}
