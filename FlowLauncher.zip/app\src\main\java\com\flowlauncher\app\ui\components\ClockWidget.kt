package com.flowlauncher.app.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import com.flowlauncher.app.model.ClockStyle
import com.flowlauncher.app.model.TextAlignment

fun TextAlignment.toTextAlign(): TextAlign = when (this) {
    TextAlignment.LEFT -> TextAlign.Start
    TextAlignment.CENTER -> TextAlign.Center
    TextAlignment.RIGHT -> TextAlign.End
}

fun TextAlignment.toHorizontalAlignment(): Alignment.Horizontal = when (this) {
    TextAlignment.LEFT -> Alignment.Start
    TextAlignment.CENTER -> Alignment.CenterHorizontally
    TextAlignment.RIGHT -> Alignment.End
}

@Composable
fun ClockWidget(
    modifier: Modifier = Modifier,
    textAlignment: TextAlignment = TextAlignment.LEFT,
    clockStyle: ClockStyle = ClockStyle.LARGE_MINIMAL,
    fontScale: Float = 1f
) {
    if (clockStyle == ClockStyle.HIDDEN) return

    val isAnalog = clockStyle == ClockStyle.ANALOG_CLEAN
    val updateInterval = if (isAnalog) 1000L else 60_000L - (System.currentTimeMillis() % 60_000L)

    var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(isAnalog) {
        while (true) {
            currentTime = System.currentTimeMillis()
            val delayMs = if (isAnalog) 1000L else {
                val now = System.currentTimeMillis()
                60_000L - (now % 60_000L)
            }
            delay(delayMs)
        }
    }

    val calendar = remember(currentTime) {
        Calendar.getInstance().apply { timeInMillis = currentTime }
    }

    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val minute = calendar.get(Calendar.MINUTE)
    val second = calendar.get(Calendar.SECOND)

    val hourStr = remember(hour) { String.format("%02d", hour) }
    val minuteStr = remember(minute) { String.format("%02d", minute) }

    val dateFormat = remember { SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()) }
    val dayOfWeekFormat = remember { SimpleDateFormat("EEEE", Locale.getDefault()) }
    val fullDateFormat = remember { SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()) }

    val dateString = remember(currentTime / 60000) { dateFormat.format(Date(currentTime)) }
    val dayOfWeek = remember(currentTime / 60000) { dayOfWeekFormat.format(Date(currentTime)) }
    val fullDate = remember(currentTime / 60000) { fullDateFormat.format(Date(currentTime)) }

    when (clockStyle) {
        ClockStyle.LARGE_MINIMAL -> LargeMinimalClock(
            modifier = modifier,
            hourStr = hourStr,
            minuteStr = minuteStr,
            dateString = dateString,
            textAlignment = textAlignment,
            fontScale = fontScale
        )
        ClockStyle.DIGITAL_BOLD -> DigitalBoldClock(
            modifier = modifier,
            hourStr = hourStr,
            minuteStr = minuteStr,
            dayOfWeek = dayOfWeek,
            textAlignment = textAlignment,
            fontScale = fontScale
        )
        ClockStyle.ANALOG_CLEAN -> AnalogCleanClock(
            modifier = modifier,
            hour = hour,
            minute = minute,
            second = second,
            textAlignment = textAlignment
        )
        ClockStyle.DATE_FOCUSED -> DateFocusedClock(
            modifier = modifier,
            hourStr = hourStr,
            minuteStr = minuteStr,
            fullDate = fullDate,
            textAlignment = textAlignment,
            fontScale = fontScale
        )
        ClockStyle.HIDDEN -> { /* no-op */ }
    }
}

@Composable
private fun RollingDigit(
    digit: Char,
    style: @Composable () -> Unit = {},
    fontSize: Float,
    fontWeight: FontWeight,
    color: Color,
    textAlign: TextAlign
) {
    AnimatedContent(
        targetState = digit,
        transitionSpec = {
            (slideInVertically(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessLow
                )
            ) { -it } + fadeIn(
                animationSpec = tween(300, easing = EaseOutCubic)
            )).togetherWith(
                slideOutVertically(
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                ) { it } + fadeOut(
                    animationSpec = tween(150, easing = EaseOutCubic)
                )
            )
        },
        label = "rolling_digit"
    ) { targetDigit ->
        Text(
            text = targetDigit.toString(),
            fontSize = fontSize.sp,
            fontWeight = fontWeight,
            color = color,
            textAlign = textAlign
        )
    }
}

@Composable
private fun RollingTimeText(
    timeStr: String,
    fontSize: Float,
    fontWeight: FontWeight,
    color: Color,
    textAlign: TextAlign
) {
    Row {
        timeStr.forEach { char ->
            if (char == ':') {
                Text(
                    text = ":",
                    fontSize = fontSize.sp,
                    fontWeight = fontWeight,
                    color = color,
                    textAlign = textAlign
                )
            } else {
                RollingDigit(
                    digit = char,
                    fontSize = fontSize,
                    fontWeight = fontWeight,
                    color = color,
                    textAlign = textAlign
                )
            }
        }
    }
}

@Composable
private fun LargeMinimalClock(
    modifier: Modifier,
    hourStr: String,
    minuteStr: String,
    dateString: String,
    textAlignment: TextAlignment,
    fontScale: Float
) {
    val textColor = MaterialTheme.colorScheme.onBackground
    val secondaryColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = textAlignment.toHorizontalAlignment()
    ) {
        RollingTimeText(
            timeStr = "$hourStr:$minuteStr",
            fontSize = 72f * fontScale,
            fontWeight = FontWeight.Thin,
            color = textColor,
            textAlign = textAlignment.toTextAlign()
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = dateString,
            fontSize = (14f * fontScale).sp,
            fontWeight = FontWeight.Light,
            color = secondaryColor,
            textAlign = textAlignment.toTextAlign()
        )
    }
}

@Composable
private fun DigitalBoldClock(
    modifier: Modifier,
    hourStr: String,
    minuteStr: String,
    dayOfWeek: String,
    textAlignment: TextAlignment,
    fontScale: Float
) {
    val textColor = MaterialTheme.colorScheme.onBackground
    val accentColor = MaterialTheme.colorScheme.primary

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = textAlignment.toHorizontalAlignment()
    ) {
        RollingTimeText(
            timeStr = "$hourStr:$minuteStr",
            fontSize = 64f * fontScale,
            fontWeight = FontWeight.Black,
            color = textColor,
            textAlign = textAlignment.toTextAlign()
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = dayOfWeek.uppercase(),
            fontSize = (16f * fontScale).sp,
            fontWeight = FontWeight.Bold,
            color = accentColor,
            letterSpacing = 4.sp,
            textAlign = textAlignment.toTextAlign()
        )
    }
}

@Composable
private fun AnalogCleanClock(
    modifier: Modifier,
    hour: Int,
    minute: Int,
    second: Int,
    textAlignment: TextAlignment
) {
    val onBackground = MaterialTheme.colorScheme.onBackground
    val primary = MaterialTheme.colorScheme.primary
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant

    val animatedSecond by animateFloatAsState(
        targetValue = second.toFloat(),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "second_hand"
    )

    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = when (textAlignment) {
            TextAlignment.LEFT -> Alignment.CenterStart
            TextAlignment.CENTER -> Alignment.Center
            TextAlignment.RIGHT -> Alignment.CenterEnd
        }
    ) {
        Canvas(
            modifier = Modifier.size(180.dp)
        ) {
            val centerX = size.width / 2
            val centerY = size.height / 2
            val radius = min(centerX, centerY) * 0.9f

            // Draw hour markers
            for (i in 0 until 12) {
                val angle = Math.toRadians((i * 30.0) - 90.0)
                val isQuarter = i % 3 == 0
                val markerLength = if (isQuarter) radius * 0.15f else radius * 0.08f
                val markerWidth = if (isQuarter) 2.5f else 1.2f

                val outerX = centerX + (radius * cos(angle)).toFloat()
                val outerY = centerY + (radius * sin(angle)).toFloat()
                val innerX = centerX + ((radius - markerLength) * cos(angle)).toFloat()
                val innerY = centerY + ((radius - markerLength) * sin(angle)).toFloat()

                drawLine(
                    color = onBackground.copy(alpha = if (isQuarter) 0.9f else 0.4f),
                    start = Offset(innerX, innerY),
                    end = Offset(outerX, outerY),
                    strokeWidth = markerWidth.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // Hour hand
            val hourAngle = ((hour % 12) + minute / 60f) * 30f - 90f
            val hourRad = Math.toRadians(hourAngle.toDouble())
            val hourLength = radius * 0.5f
            drawLine(
                color = onBackground,
                start = Offset(centerX, centerY),
                end = Offset(
                    centerX + (hourLength * cos(hourRad)).toFloat(),
                    centerY + (hourLength * sin(hourRad)).toFloat()
                ),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Minute hand
            val minuteAngle = minute * 6f - 90f
            val minuteRad = Math.toRadians(minuteAngle.toDouble())
            val minuteLength = radius * 0.72f
            drawLine(
                color = onBackground,
                start = Offset(centerX, centerY),
                end = Offset(
                    centerX + (minuteLength * cos(minuteRad)).toFloat(),
                    centerY + (minuteLength * sin(minuteRad)).toFloat()
                ),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Second hand
            val secondAngle = animatedSecond * 6f - 90f
            val secondRad = Math.toRadians(secondAngle.toDouble())
            val secondLength = radius * 0.8f
            drawLine(
                color = primary,
                start = Offset(
                    centerX - (radius * 0.1f * cos(secondRad)).toFloat(),
                    centerY - (radius * 0.1f * sin(secondRad)).toFloat()
                ),
                end = Offset(
                    centerX + (secondLength * cos(secondRad)).toFloat(),
                    centerY + (secondLength * sin(secondRad)).toFloat()
                ),
                strokeWidth = 1.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Center dot
            drawCircle(
                color = primary,
                radius = 4.dp.toPx(),
                center = Offset(centerX, centerY)
            )
        }
    }
}

@Composable
private fun DateFocusedClock(
    modifier: Modifier,
    hourStr: String,
    minuteStr: String,
    fullDate: String,
    textAlignment: TextAlignment,
    fontScale: Float
) {
    val textColor = MaterialTheme.colorScheme.onBackground
    val secondaryColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = textAlignment.toHorizontalAlignment()
    ) {
        Text(
            text = fullDate,
            fontSize = (32f * fontScale).sp,
            fontWeight = FontWeight.Medium,
            color = textColor,
            textAlign = textAlignment.toTextAlign()
        )

        Spacer(modifier = Modifier.height(4.dp))

        RollingTimeText(
            timeStr = "$hourStr:$minuteStr",
            fontSize = 20f * fontScale,
            fontWeight = FontWeight.Light,
            color = secondaryColor,
            textAlign = textAlignment.toTextAlign()
        )
    }
}
