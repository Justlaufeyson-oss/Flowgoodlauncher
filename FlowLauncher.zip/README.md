# Flow Launcher

A lightweight, snappy, and fluid Android home screen launcher inspired by Niagara Launcher, written with modern **Kotlin** and **Jetpack Compose** (Material3).

---

## ✨ Features

### 🚀 Niagara Parity & Performance
- **Fluid Spring Animations**: Pure spring-physics animations throughout all interactions (app drawer slide, overscroll bouncing, button taps, and widget collapses).
- **One-Handed Usability**: Ergonomic layout optimized for natural thumb reach on any device size.
- **Adaptive Alphabet Scroller**: Signature A–Z edge scroller with tactile touch feedback, dynamic letter balloon indicator, and smooth lazy list synchronization.
- **Wall-through Edge-to-Edge Canvas**: Fully transparent window overlay allowing live wallpapers and system backdrops to display without occlusion.
- **Fuzzy Search Engine**: Substring and ordered character sequence fuzzy matching across installed applications with real-time highlighted query matches.

### 🎨 Themes & Customization
- **7 Built-in Theme Palettes**:
  - `Dark`: Deep material gray with violet accent
  - `Light`: Crisp clean white with blue accent
  - `AMOLED`: Pure `#000000` pitch black optimized for OLED battery saving
  - `Ocean`: Deep navy and cyan marine aesthetics
  - `Sunset`: Warm burnt orange and copper tones
  - `Forest`: Emerald green and natural olive accents
  - `Rose`: Soft rose and magenta pastels
- **Customizable Clock Styles**:
  - Large Minimal (HH:mm with clean date display)
  - Digital Bold (commanding block numbers)
  - Analog Clean (custom Canvas-rendered minimal geometric clock)
  - Date Focused (prominent calendar day & month)
  - Hidden (for maximum wallpaper visibility)
- **Home Alignment**: Left, Center, or Right alignment options.
- **Font Scale Adjustment**: 0.8x to 1.4x dynamic typography scaling.
- **App Management**: Custom app renaming, hiding unwanted applications, and quick app info/uninstall shortcuts.

### 💎 Niagara Pro Equivalent Features
- **Dynamic Calendar Agenda**:
  - Automatically queries upcoming appointments, meetings, and all-day events from `CalendarContract`.
  - Pulse glow indicator for currently ongoing events.
  - Expandable / collapsible glassmorphic summary card directly underneath the clock.
- **Pop-up Widget Stack**:
  - Floating card stack accessible via one tap or edge gesture.
  - Quick Notes scratchpad (persisted to DataStore).
  - Media Controls card placeholder with responsive playback controls.
  - Screen Time tracker with circular progress indicator.
  - System Quick Toggles (Wi-Fi, Bluetooth, Flashlight, Do Not Disturb).
  - Quick Contacts shelf.
- **Gestures**:
  - Swipe down from upper screen to expand notification shade.
  - Swipe up from anywhere to reveal the full app drawer.
  - Double tap to lock screen option.

---

## 📂 Project Structure

```
FlowLauncher/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/flowlauncher/app/
│       │   ├── FlowLauncherApp.kt
│       │   ├── MainActivity.kt
│       │   ├── model/
│       │   │   └── AppInfo.kt          # AppInfo, CalendarEvent, LauncherTheme, ClockStyle, etc.
│       │   ├── data/
│       │   │   ├── AppRepository.kt    # PackageManager & Calendar queries with fuzzy search
│       │   │   └── PreferencesManager.kt # Jetpack DataStore preferences & reactive flows
│       │   ├── receiver/
│       │   │   └── PackageChangeReceiver.kt # Real-time app install/uninstall broadcaster
│       │   ├── viewmodel/
│       │   │   └── LauncherViewModel.kt # StateFlows & reactive business logic
│       │   └── ui/
│       │       ├── theme/
│       │       │   ├── Color.kt
│       │       │   ├── Theme.kt
│       │       │   └── Type.kt
│       │       ├── components/
│       │       │   ├── AlphabetScroller.kt
│       │       │   ├── AppList.kt
│       │       │   ├── CalendarAgenda.kt
│       │       │   ├── ClockWidget.kt
│       │       │   ├── SearchOverlay.kt
│       │       │   └── WidgetStack.kt
│       │       ├── screens/
│       │       │   ├── HomeScreen.kt
│       │       │   └── SettingsScreen.kt
│       │       └── navigation/
│       │           └── NavGraph.kt
│       └── res/
│           ├── drawable/
│           ├── mipmap-anydpi-v26/
│           └── values/
├── gradle/
│   └── wrapper/
│       └── gradle-wrapper.properties
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── gradlew.bat
```

---

## 🛠️ How to Build the APK

### Prerequisites
1. **Android Studio** (Hedgehog 2023.1.1 or newer recommended) OR **Android SDK Command-line Tools** with SDK Platform 34.
2. **JDK 17** (or Java 17+ installed and set to `JAVA_HOME`).

### Option 1: Using Android Studio (Recommended)
1. Open Android Studio.
2. Select **Open** and choose the `FlowLauncher` folder (`C:\Users\shrey\.gemini\antigravity\scratch\FlowLauncher`).
3. Allow Gradle to synchronize dependencies.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

### Option 2: Using the Command Line
Open a terminal in the `FlowLauncher` directory and execute:

```powershell
# Set your ANDROID_HOME (adjust to your Android SDK location):
$env:ANDROID_HOME = "C:\Users\$env:USERNAME\AppData\Local\Android\Sdk"

# Build debug APK:
.\gradlew.bat assembleDebug
```

The APK will be located at:
`app\build\outputs\apk\debug\app-debug.apk`

To install directly to a connected Android phone or emulator via ADB:
```powershell
adb install -r app\build\outputs\apk\debug\app-debug.apk
```
