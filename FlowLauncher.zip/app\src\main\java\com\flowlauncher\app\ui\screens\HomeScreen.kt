package com.flowlauncher.app.ui.screens

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import com.flowlauncher.app.model.CalendarEvent
import com.flowlauncher.app.model.TextAlignment
import com.flowlauncher.app.ui.components.*
import com.flowlauncher.app.viewmodel.LauncherViewModel
import kotlinx.coroutines.launch

@SuppressLint("WrongConstant")
private fun expandNotificationShade(context: Context) {
    try {
        val service = context.getSystemService("statusbar")
        val statusbarManager = Class.forName("android.app.StatusBarManager")
        val expand = statusbarManager.getMethod("expandNotificationsPanel")
        expand.invoke(service)
    } catch (_: Exception) {
        // Fallback for devices restricting access
    }
}

@Composable
fun HomeScreen(
    viewModel: LauncherViewModel,
    navController: NavController,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val clockStyle by viewModel.clockStyle.collectAsState()
    val textAlignment by viewModel.textAlignment.collectAsState()
    val fontScale by viewModel.fontScale.collectAsState()
    val showCalendar by viewModel.showCalendar.collectAsState()
    val showWidgetStack by viewModel.showWidgetStack.collectAsState()
    val calendarEvents by viewModel.calendarEvents.collectAsState()
    val isAppDrawerOpen by viewModel.isAppDrawerOpen.collectAsState()
    val isSearchActive by viewModel.isSearchActive.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filteredApps by viewModel.filteredApps.collectAsState()
    val isWidgetStackOpen by viewModel.isWidgetStackOpen.collectAsState()
    val appToRename by viewModel.appToRename.collectAsState()
    val swipeDownNotifications by viewModel.swipeDownNotifications.collectAsState()

    val drawerListState = rememberLazyListState()

    // Handle back button
    BackHandler(enabled = isSearchActive || isAppDrawerOpen || isWidgetStackOpen) {
        if (isSearchActive) {
            viewModel.setSearchActive(false)
        } else if (isWidgetStackOpen) {
            viewModel.closeWidgetStack()
        } else if (isAppDrawerOpen) {
            viewModel.closeAppDrawer()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var dragStartY = 0f
                var totalDragY = 0f
                detectDragGestures(
                    onDragStart = { offset ->
                        dragStartY = offset.y
                        totalDragY = 0f
                    },
                    onDrag = { _, dragAmount ->
                        totalDragY += dragAmount.y
                    },
                    onDragEnd = {
                        // Swipe down from top half to expand notifications
                        if (totalDragY > 120f && dragStartY < size.height * 0.4f && swipeDownNotifications) {
                            expandNotificationShade(context)
                        }
                        // Swipe up from bottom half to open app drawer
                        else if (totalDragY < -120f && !isAppDrawerOpen) {
                            viewModel.openAppDrawer()
                        }
                    }
                )
            }
    ) {
        // ── Main Home Screen Content ─────────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Top action row (search button, widget stack toggle, settings)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (showWidgetStack) {
                    IconButton(
                        onClick = { viewModel.toggleWidgetStack() },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "Widget Stack",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                IconButton(
                    onClick = { viewModel.setSearchActive(true) },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = { navController.navigate("settings") },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Clock & Date Widget
            ClockWidget(
                textAlignment = textAlignment,
                clockStyle = clockStyle,
                fontScale = fontScale,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            )

            // Calendar Agenda Widget
            if (showCalendar && calendarEvents.isNotEmpty()) {
                CalendarAgenda(
                    events = calendarEvents,
                    onEventClick = { event ->
                        try {
                            val uri = Uri.parse("content://com.android.calendar/events/${event.id}")
                            val intent = Intent(Intent.ACTION_VIEW, uri)
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            val intent = Intent(Intent.ACTION_MAIN).apply {
                                addCategory(Intent.CATEGORY_APP_CALENDAR)
                            }
                            context.startActivity(intent)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Niagara-style Favorite Apps List
            FavoriteAppList(
                viewModel = viewModel,
                onAppLaunch = { app -> viewModel.launchApp(context, app.packageName) },
                onOpenAppDrawer = { viewModel.openAppDrawer() },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            )

            // Bottom subtle swipe hint
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .clickable { viewModel.openAppDrawer() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Swipe up for all apps",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                        fontSize = 12.sp
                    )
                )
            }
        }

        // ── Full App Drawer Drawer/Sheet ─────────────────────────────────────
        AnimatedVisibility(
            visible = isAppDrawerOpen,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow)
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = spring(stiffness = Spring.StiffnessMedium)
            ) + fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.94f))
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Header with title and close button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "All Apps",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        IconButton(onClick = { viewModel.closeAppDrawer() }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }

                    // App Drawer List with Alphabet Scroller
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        FullAppList(
                            viewModel = viewModel,
                            listState = drawerListState,
                            searchQuery = searchQuery,
                            onAppLaunch = { app ->
                                viewModel.closeAppDrawer()
                                viewModel.launchApp(context, app.packageName)
                            },
                            modifier = Modifier.fillMaxSize()
                        )

                        // Alphabet Scroller on the right
                        val availableLetters = remember(viewModel.allApps) {
                            viewModel.allApps.value
                                .mapNotNull { it.displayName.firstOrNull()?.uppercaseChar() }
                                .filter { it in 'A'..'Z' }
                                .toSet()
                        }

                        AlphabetScroller(
                            availableLetters = availableLetters,
                            onLetterSelected = { letter ->
                                coroutineScope.launch {
                                    val index = viewModel.allApps.value.indexOfFirst {
                                        it.displayName.startsWith(letter, ignoreCase = true)
                                    }
                                    if (index >= 0) {
                                        drawerListState.animateScrollToItem(index)
                                    }
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .fillMaxHeight()
                                .padding(end = 4.dp)
                        )
                    }
                }
            }
        }

        // ── Niagara Pro Pop-up Widget Stack ──────────────────────────────────
        WidgetStack(
            isVisible = isWidgetStackOpen,
            onDismiss = { viewModel.closeWidgetStack() }
        )

        // ── Search Overlay ───────────────────────────────────────────────────
        SearchOverlay(
            searchQuery = searchQuery,
            onQueryChange = { viewModel.updateSearchQuery(it) },
            filteredApps = filteredApps.map { SearchableApp(it.packageName, it.displayLabel) },
            onAppClick = { searchable ->
                viewModel.setSearchActive(false)
                viewModel.launchApp(context, searchable.packageName)
            },
            onDismiss = { viewModel.setSearchActive(false) },
            isVisible = isSearchActive
        )

        // ── Rename App Dialog ────────────────────────────────────────────────
        appToRename?.let { app ->
            var newName by remember { mutableStateOf(app.displayLabel) }

            Dialog(onDismissRequest = { viewModel.dismissRename() }) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Rename App",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )

                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            label = { Text("App Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { viewModel.dismissRename() }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    viewModel.renameApp(app.packageName, newName.trim())
                                }
                            ) {
                                Text("Save")
                            }
                        }
                    }
                }
            }
        }
    }
}
