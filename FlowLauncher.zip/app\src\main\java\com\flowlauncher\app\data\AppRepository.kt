package com.flowlauncher.app.data

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.CalendarContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.flowlauncher.app.model.AppInfo
import com.flowlauncher.app.model.CalendarEvent

object AppRepository {

    private const val LAUNCHER_PACKAGE = "com.flowlauncher.app"

    /**
     * Query PackageManager for all launchable apps, filtering out the launcher itself.
     * Returns the list sorted alphabetically by label.
     */
    fun loadInstalledApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)

        return resolveInfos
            .filter { it.activityInfo.packageName != LAUNCHER_PACKAGE }
            .map { resolveInfo ->
                val activityInfo = resolveInfo.activityInfo
                val appLabel = resolveInfo.loadLabel(pm).toString()
                val isSystem = (activityInfo.applicationInfo.flags and
                        android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                val component = "${activityInfo.packageName}/${activityInfo.name}"

                AppInfo(
                    packageName = activityInfo.packageName,
                    label = appLabel,
                    isSystemApp = isSystem,
                    componentName = component
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    /**
     * Query CalendarContract for upcoming events within the next [daysAhead] days.
     * Returns an empty list if calendar permission is not granted.
     */
    fun loadCalendarEvents(context: Context, daysAhead: Int = 3): List<CalendarEvent> {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_CALENDAR
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return emptyList()
        }

        val now = System.currentTimeMillis()
        val end = now + daysAhead.toLong() * 24 * 60 * 60 * 1000

        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.CALENDAR_COLOR,
            CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.ALL_DAY
        )

        val selection = "${CalendarContract.Instances.BEGIN} >= ? OR " +
                "(${CalendarContract.Instances.BEGIN} <= ? AND ${CalendarContract.Instances.END} >= ?)"
        val selectionArgs = arrayOf(now.toString(), now.toString(), now.toString())
        val sortOrder = "${CalendarContract.Instances.BEGIN} ASC"

        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
            .appendPath(now.toString())
            .appendPath(end.toString())
            .build()

        val events = mutableListOf<CalendarEvent>()
        var cursor: Cursor? = null

        try {
            cursor = context.contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )

            cursor?.let {
                val idIdx = it.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_ID)
                val titleIdx = it.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)
                val beginIdx = it.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN)
                val endIdx = it.getColumnIndexOrThrow(CalendarContract.Instances.END)
                val colorIdx = it.getColumnIndexOrThrow(CalendarContract.Instances.CALENDAR_COLOR)
                val locationIdx = it.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_LOCATION)
                val allDayIdx = it.getColumnIndexOrThrow(CalendarContract.Instances.ALL_DAY)

                while (it.moveToNext()) {
                    val title = it.getString(titleIdx)
                    if (title.isNullOrBlank()) continue

                    events.add(
                        CalendarEvent(
                            id = it.getLong(idIdx),
                            title = title,
                            startTime = it.getLong(beginIdx),
                            endTime = it.getLong(endIdx),
                            calendarColor = it.getInt(colorIdx),
                            location = it.getString(locationIdx)?.takeIf { loc -> loc.isNotBlank() },
                            isAllDay = it.getInt(allDayIdx) == 1
                        )
                    )
                }
            }
        } catch (_: Exception) {
            // Gracefully handle any query failures
        } finally {
            cursor?.close()
        }

        return events
    }

    /**
     * Return the launch intent for a given package.
     */
    fun getLaunchIntent(context: Context, packageName: String): Intent? {
        return context.packageManager.getLaunchIntentForPackage(packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    /**
     * Return the application icon Drawable for a given package.
     */
    fun getAppIcon(context: Context, packageName: String): Drawable? {
        return try {
            context.packageManager.getApplicationIcon(packageName)
        } catch (_: PackageManager.NameNotFoundException) {
            null
        }
    }

    /**
     * Filter apps by query matching label or custom label.
     * Supports fuzzy matching: checks if query characters appear in order in the label.
     */
    fun searchApps(apps: List<AppInfo>, query: String): List<AppInfo> {
        if (query.isBlank()) return apps

        val lowerQuery = query.trim().lowercase()

        return apps.filter { app ->
            val label = app.displayLabel.lowercase()

            // Exact substring match (higher priority, but we include all matches)
            if (label.contains(lowerQuery)) return@filter true

            // Fuzzy match: query chars appear in order in the label
            fuzzyMatch(label, lowerQuery)
        }.sortedWith(compareBy(
            // Prioritize exact prefix matches
            { !it.displayLabel.lowercase().startsWith(lowerQuery) },
            // Then substring matches
            { !it.displayLabel.lowercase().contains(lowerQuery) },
            // Then alphabetical
            { it.displayLabel.lowercase() }
        ))
    }

    private fun fuzzyMatch(text: String, query: String): Boolean {
        var queryIndex = 0
        for (char in text) {
            if (queryIndex < query.length && char == query[queryIndex]) {
                queryIndex++
            }
        }
        return queryIndex == query.length
    }

    /**
     * Launch the system uninstall dialog for a given package.
     */
    fun uninstallApp(context: Context, packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:$packageName")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * Open the system app info / details screen for a given package.
     */
    fun getAppInfo(context: Context, packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
