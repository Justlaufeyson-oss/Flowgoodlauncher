package com.flowlauncher.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Data class representing a search-result app entry.
 */
data class SearchableApp(
    val packageName: String,
    val appName: String,
    val icon: Painter? = null
)

/**
 * Full-screen search overlay with animated entry, auto-focused search bar,
 * real-time app filtering with highlighted matching characters, and
 * staggered result animations.
 *
 * The overlay appears with a fade-in scrim and the search bar slides down
 * from the top. Results animate in with staggered spring-based fade effects.
 */
@Composable
fun SearchOverlay(
    searchQuery: String,
    onQueryChange: (String) -> Unit,
    filteredApps: List<SearchableApp>,
    onAppClick: (SearchableApp) -> Unit,
    onDismiss: () -> Unit,
    isVisible: Boolean,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn(
            animationSpec = spring(stiffness = Spring.StiffnessMedium)
        ),
        exit = fadeOut(
            animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
        )
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.7f))
        ) {
            // Tap above the search bar area to dismiss
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = {
                            keyboardController?.hide()
                            onDismiss()
                        }
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = { /* Consume click to prevent dismiss */ }
                    )
            ) {
                // Search bar - slides down from top
                AnimatedVisibility(
                    visible = true,
                    enter = slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        ),
                        initialOffsetY = { -it }
                    ) + fadeIn(
                        animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
                    ),
                    exit = slideOutVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        targetOffsetY = { -it }
                    ) + fadeOut()
                ) {
                    SearchBar(
                        query = searchQuery,
                        onQueryChange = onQueryChange,
                        onDismiss = {
                            keyboardController?.hide()
                            onDismiss()
                        },
                        focusRequester = focusRequester,
                        modifier = Modifier.padding(
                            horizontal = 16.dp,
                            vertical = 12.dp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Results
                if (searchQuery.isNotEmpty() && filteredApps.isEmpty()) {
                    // No results state
                    NoResultsState()
                } else if (searchQuery.isNotEmpty()) {
                    // Filtered results list
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        itemsIndexed(
                            items = filteredApps,
                            key = { _, app -> app.packageName }
                        ) { index, app ->
                            AnimatedVisibility(
                                visible = true,
                                enter = fadeIn(
                                    animationSpec = tween(
                                        durationMillis = 200,
                                        delayMillis = index * 30
                                    )
                                ) + slideInVertically(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioLowBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    ),
                                    initialOffsetY = { it / 2 }
                                ),
                                exit = fadeOut()
                            ) {
                                SearchResultItem(
                                    app = app,
                                    query = searchQuery,
                                    onClick = {
                                        keyboardController?.hide()
                                        onAppClick(app)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Auto-focus the search field when the overlay becomes visible
        LaunchedEffect(Unit) {
            focusRequester.requestFocus()
            keyboardController?.show()
        }
    }
}

/**
 * Search bar with back button, text input, and clear button.
 */
@Composable
private fun SearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onDismiss: () -> Unit,
    focusRequester: FocusRequester,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.12f),
                        Color.White.copy(alpha = 0.08f)
                    )
                )
            )
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Back button
        IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(40.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White.copy(alpha = 0.7f),
                modifier = Modifier.size(22.dp)
            )
        }

        // Text field
        BasicTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 8.dp)
                .focusRequester(focusRequester),
            textStyle = TextStyle(
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 16.sp
            ),
            singleLine = true,
            cursorBrush = SolidColor(Color.White.copy(alpha = 0.6f)),
            keyboardOptions = KeyboardOptions(
                imeAction = ImeAction.Search
            ),
            keyboardActions = KeyboardActions(
                onSearch = { /* Could trigger first result launch */ }
            ),
            decorationBox = { innerTextField ->
                Box {
                    if (query.isEmpty()) {
                        Text(
                            text = "Search apps...",
                            style = TextStyle(
                                color = Color.White.copy(alpha = 0.35f),
                                fontSize = 16.sp
                            )
                        )
                    }
                    innerTextField()
                }
            }
        )

        // Clear button
        if (query.isNotEmpty()) {
            IconButton(
                onClick = { onQueryChange("") },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Clear search",
                    tint = Color.White.copy(alpha = 0.5f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/**
 * Individual search result row with icon placeholder and highlighted matching text.
 */
@Composable
private fun SearchResultItem(
    app: SearchableApp,
    query: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App icon placeholder
        if (app.icon != null) {
            Icon(
                painter = app.icon,
                contentDescription = null,
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp)),
                tint = Color.Unspecified
            )
        } else {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF6366F1).copy(alpha = 0.5f),
                                Color(0xFF8B5CF6).copy(alpha = 0.5f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = app.appName.firstOrNull()?.uppercase() ?: "?",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White.copy(alpha = 0.9f),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        // App name with highlighted matching characters
        Text(
            text = buildHighlightedText(app.appName, query),
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White.copy(alpha = 0.8f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = 15.sp
        )
    }
}

/**
 * Builds an AnnotatedString that highlights matching characters in bold
 * with an accent color.
 */
@Composable
private fun buildHighlightedText(
    text: String,
    query: String
): androidx.compose.ui.text.AnnotatedString {
    if (query.isBlank()) {
        return buildAnnotatedString { append(text) }
    }

    val highlightColor = Color(0xFF82B1FF)
    val normalColor = Color.White.copy(alpha = 0.75f)

    return buildAnnotatedString {
        val lowerText = text.lowercase()
        val lowerQuery = query.lowercase()

        var currentIndex = 0
        var searchFrom = 0

        while (currentIndex < text.length) {
            val matchIndex = lowerText.indexOf(lowerQuery, searchFrom)

            if (matchIndex == -1 || currentIndex > matchIndex) {
                // No more matches, append remaining text normally
                withStyle(SpanStyle(color = normalColor)) {
                    append(text.substring(currentIndex))
                }
                break
            }

            // Append text before match
            if (currentIndex < matchIndex) {
                withStyle(SpanStyle(color = normalColor)) {
                    append(text.substring(currentIndex, matchIndex))
                }
            }

            // Append matched text with highlight
            val matchEnd = (matchIndex + lowerQuery.length).coerceAtMost(text.length)
            withStyle(
                SpanStyle(
                    color = highlightColor,
                    fontWeight = FontWeight.Bold
                )
            ) {
                append(text.substring(matchIndex, matchEnd))
            }

            currentIndex = matchEnd
            searchFrom = matchEnd
        }
    }
}

/**
 * "No apps found" empty state with subtle styling.
 */
@Composable
private fun NoResultsState() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 48.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "¯\\_(ツ)_/¯",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White.copy(alpha = 0.25f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "No apps found",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.35f),
                fontWeight = FontWeight.Light
            )
        }
    }
}
